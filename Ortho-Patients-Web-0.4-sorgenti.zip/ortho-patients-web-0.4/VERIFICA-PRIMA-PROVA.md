# Prima prova della 0.4 web

1. Apri il link e scegli **Entra nella demo**.
2. In Agenda controlla che la linea **Adesso** sia tra gli appuntamenti prima e dopo l'ora attuale.
3. Cerca **Bianchi**: scegliendo Giulia devono cambiare automaticamente studio e motivo.
4. Modifica il motivo e aggiungi un appuntamento. La riga dell'appuntamento deve essere modificabile.
5. Passa a Settimana: l'appuntamento deve restare visibile e modificabile.
6. Premi **Salva** e verifica che venga scaricato il backup JSON.
7. Esci dalla demo e rientra: le modifiche dimostrative devono essere azzerate.
8. Torna all'inizio e apri l'archivio locale: al primo accesso scegli personalmente la password.
9. Crea un paziente fittizio, ricarica, riapri l'archivio e sbloccalo: il paziente deve essere ancora presente.
10. Ripeti la prova su Safari e sul computer del collega.

Usare solo dati fittizi nella prova. Non cancellare i dati del browser senza aver prima esportato un backup.
