# Ortho Patients Web 0.4

Release 15.10.2026. Versione browser della copia Mac 0.4, preparata per una prova tramite GitHub Pages.

## Come si usa

- **Entra nella demo**: tre pazienti fittizi, due studi e appuntamenti di oggi. Le modifiche durano solo durante la sessione. Uscendo o ricaricando, la demo si ricrea.
- **Apri archivio locale**: archivio indipendente in questo browser, inizialmente vuoto. Al primo accesso scegli una password; in seguito usala per sbloccarlo.
- **Salva** scarica un backup JSON. **Carica** importa un backup Mac/Web e sostituisce l'archivio aperto. Da Preferenze puoi unire gli archivi con Merge.
- In Preferenze trovi versione, data release, gestione studi e sequenze, backup e opzioni dell'archivio locale.

Schede, foto e appuntamenti restano nel browser, tramite IndexedDB. Non sono sincronizzati tra dispositivi o tra browser. La cancellazione dei dati del sito cancella anche l'archivio: conserva backup esterni. La password blocca l'interfaccia locale ma non cifra l'archivio nel browser. I backup possono essere cifrati con la password dell'app. Il sito non comprende account online, server o database condivisi.

Per la prova con colleghi usare pazienti fittizi. La demo non legge né modifica l'archivio personale. Non sono inclusi database reali, foto cliniche, credenziali o dati dell'app Mac.

## Eseguire in locale

Richiede Node.js 22.12 o successivo e npm.

```sh
npm ci
npm test
npm run build
npm run check
npm run preview
```

Apri l'indirizzo locale stampato dal comando di anteprima. Non aprire `dist/index.html` con un doppio clic: i moduli JavaScript richiedono un server web.

## Pubblicare su GitHub Pages

1. Crea un repository dedicato, ad esempio `ortho-patients-web`, e usa il ramo `main`.
2. Carica solo i file di questa cartella, compresa `.github/workflows/pages.yml`; escludi `node_modules`, archivi personali e file di backup.
3. Nel repository apri **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. In **Actions** avvia il workflow **Pubblica Ortho Patients Web** se non è già partito.
5. Attendi il completamento di build e deploy: il workflow restituisce il link effettivo del sito.

Su GitHub Free, Pages richiede normalmente un repository pubblico. I file pubblicati sono il programma e i dati fittizi della demo: non caricare backup personali. I dati inseriti dai visitatori non vengono aggiunti al repository.

Il percorso base è relativo: il sito funziona anche in una sottocartella, come `/<nome-repository>/`. L'indirizzo del sito deve restare stabile per ritrovare l'archivio nello stesso browser.

## Controlli eseguiti

- Compilazione della versione di produzione e verifica percorsi relativi.
- Test agenda: posizione dell'ora attuale, studio e motivo copiati dalla scheda.
- Demo: dati indipendenti a ogni nuova sessione.
- Backup cifrato: lettura corretta e rifiuto della password errata.
- Prova nel browser: download del backup, conservazione delle modifiche, ingresso separato nell'archivio personale.
- Prova IndexedDB: salvataggio e rilettura di 6 MB e verifica dell'ordine delle scritture.

## Limiti della prima prova

Verificata nel browser integrato basato su Chromium; resta da provarla su Safari e su un secondo computer. Un browser che non supporta la scelta di un file fisso scarica ogni backup nella cartella Download. Non è prevista sincronizzazione né uso offline garantito. La pubblicazione su GitHub Pages richiede accesso al repository e non è completata finché non esiste un deploy riuscito.
