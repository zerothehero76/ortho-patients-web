import { test } from 'node:test';
import assert from 'node:assert/strict';
import { agendaTimeline, appointmentReason, localDateISO } from '../src/lib/agendaUtils.js';
import { createDemoData } from '../src/data/demo.js';
import { encryptBackupText, decryptBackupData } from '../src/lib/backupCrypto.js';

test('la demo si ricrea indipendente e associa ogni appuntamento allo studio corretto', () => {
  const now = new Date(2026, 9, 15, 13, 0);
  const first = createDemoData(now);
  const second = createDemoData(now);
  first.patients[0].nome = 'Modificato';
  first.patients[0].diagnosi.classeDentale = 'III';
  assert.equal(second.patients[0].nome, 'Mario');
  assert.equal(second.patients[0].diagnosi.classeDentale, 'I');
  for (const item of second.agendaItems) {
    const patient = second.patients.find(p => p.id === item.patientId);
    assert.equal(item.studioId, patient.studioId);
    assert.equal(item.motivo, patient.prossimoAppuntamento);
    assert.equal(item.data, '2026-10-15');
  }
  assert.equal(new Set(second.patients.map(p => p.studioId)).size, 2);
});

test('la linea Adesso divide gli appuntamenti di oggi e non compare in altri giorni', () => {
  const now = new Date(2026, 9, 15, 13, 0);
  const data = createDemoData(now);
  const rows = agendaTimeline(data.agendaItems, localDateISO(now), now);
  assert.deepEqual(rows.map(row => row.ora), ['12:00', '13:00', '13:30', '14:30']);
  assert.equal(rows[1].isNow, true);
  assert.equal(agendaTimeline(data.agendaItems, '2026-10-16', now).length, 3);
  assert.equal(appointmentReason({prossimoAppuntamento: '  Controllo elastici  '}), 'Controllo elastici');
});

test('un backup cifrato si reimporta senza perdere pazienti, foto o agenda', async () => {
  const data = createDemoData();
  data.patients[0].photoSessions = [{id:'test-photo',photos:[{dataUrl:'data:image/png;base64,dGVzdA=='}]}];
  const encrypted = JSON.parse(await encryptBackupText(JSON.stringify(data), 'Password-solo-test-0.4'));
  assert.equal(encrypted.encrypted, true);
  assert.ok(!encrypted.data.includes('Rossi'));
  assert.deepEqual(await decryptBackupData(encrypted, 'Password-solo-test-0.4'), data);
  await assert.rejects(() => decryptBackupData(encrypted, 'Password-errata'));
});
