import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import WebRoot from './WebRoot.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <WebRoot />
  </StrictMode>,
)
