import { scoreLabel } from "../lib/patientUtils";

export function Badge({ children }) {
  return <span className="badge">{children}</span>;
}

export function Button({ children, onClick, secondary = false, small = false, disabled = false }) {
  return (
    <button
      className={`btn ${secondary ? "btnSecondary" : ""} ${small ? "btnSmall" : ""}`}
      onClick={onClick}
      type="button"
      disabled={disabled}
    >
      {children}
    </button>
  );
}

export function Card({ children }) {
  return <div className="card">{children}</div>;
}

export function ScoreSlider({ label, value, onChange, type }) {
  return (
    <div className="fieldBlock">
      <div className="sliderHeader">
        <strong>{label}</strong>
        <span className="scorePill">{value}/10 · {scoreLabel(value, type)}</span>
      </div>
      <input
        type="range"
        min="0"
        max="10"
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="range"
      />
    </div>
  );
}
