import { useState } from "react";
import { Button } from "./ui";

export function ElasticDiagram({ elastici, setElastici }) {
  const teeth = [
    { n: 17, x: 30, y: 35 }, { n: 16, x: 70, y: 35 }, { n: 15, x: 110, y: 35 }, { n: 14, x: 150, y: 35 }, { n: 13, x: 190, y: 35 }, { n: 12, x: 230, y: 35 }, { n: 11, x: 270, y: 35 },
    { n: 21, x: 330, y: 35 }, { n: 22, x: 370, y: 35 }, { n: 23, x: 410, y: 35 }, { n: 24, x: 450, y: 35 }, { n: 25, x: 490, y: 35 }, { n: 26, x: 530, y: 35 }, { n: 27, x: 570, y: 35 },
    { n: 47, x: 30, y: 160 }, { n: 46, x: 70, y: 160 }, { n: 45, x: 110, y: 160 }, { n: 44, x: 150, y: 160 }, { n: 43, x: 190, y: 160 }, { n: 42, x: 230, y: 160 }, { n: 41, x: 270, y: 160 },
    { n: 31, x: 330, y: 160 }, { n: 32, x: 370, y: 160 }, { n: 33, x: 410, y: 160 }, { n: 34, x: 450, y: 160 }, { n: 35, x: 490, y: 160 }, { n: 36, x: 530, y: 160 }, { n: 37, x: 570, y: 160 }
  ];

  const [selected, setSelected] = useState([]);
  const [tipo, setTipo] = useState("II classe");
  const [forza, setForza] = useState("3/16 6oz");

  const toothByNumber = (number) => teeth.find((tooth) => tooth.n === number);

  const addToSelection = (tooth) => {
    setSelected((current) => current.includes(tooth) ? current.filter((selectedTooth) => selectedTooth !== tooth) : [...current, tooth]);
  };

  const saveElastic = () => {
    if (selected.length < 2) return;
    setElastici([...elastici, { id: `el-${Date.now()}`, tipo, forza, elementi: selected }]);
    setSelected([]);
  };

  return (
    <div className="elasticBox">
      <div className="elasticControls">
        {["II classe", "III classe", "Verticale", "Triangolare", "Box", "Cross"].map((preset) => (
          <Button key={preset} small secondary={tipo !== preset} onClick={() => setTipo(preset)}>{preset}</Button>
        ))}
        <input className="input smallInput" value={forza} onChange={(event) => setForza(event.target.value)} />
        <Button small onClick={saveElastic}>Salva elastico</Button>
      </div>

      <svg viewBox="0 0 600 200" className="elasticSvg">
        <line x1="300" y1="10" x2="300" y2="190" stroke="#cbd5e1" strokeDasharray="4" />

        {elastici.map((elastic) => {
          const points = elastic.elementi.map(toothByNumber).filter(Boolean);
          return points.map((point, index) => {
            const next = points[(index + 1) % points.length];
            if (!next || (points.length === 2 && index === 1)) return null;
            return <line key={`${elastic.id}-${index}`} x1={point.x} y1={point.y} x2={next.x} y2={next.y} stroke="#0f172a" strokeWidth="3" />;
          });
        })}

        {selected.map((number, index) => {
          const point = toothByNumber(number);
          const next = toothByNumber(selected[index + 1]);
          if (!point || !next) return null;
          return <line key={`sel-${number}`} x1={point.x} y1={point.y} x2={next.x} y2={next.y} stroke="#64748b" strokeWidth="2" strokeDasharray="4" />;
        })}

        {teeth.map((tooth) => (
          <g key={tooth.n} onClick={() => addToSelection(tooth.n)} style={{ cursor: "pointer" }}>
            <circle cx={tooth.x} cy={tooth.y} r="15" fill={selected.includes(tooth.n) ? "#0f172a" : "white"} stroke="#94a3b8" strokeWidth="2" />
            <text x={tooth.x} y={tooth.y + 4} textAnchor="middle" fontSize="10" fill={selected.includes(tooth.n) ? "white" : "#0f172a"}>{tooth.n}</text>
          </g>
        ))}
      </svg>

      <div className="elasticList">
        {elastici.length === 0 ? (
          <span className="muted">Nessun elastico attivo.</span>
        ) : (
          elastici.map((elastic) => (
            <button key={elastic.id} className="elasticChip" onClick={() => setElastici(elastici.filter((item) => item.id !== elastic.id))} type="button">
              {elastic.tipo} · {elastic.forza} · {elastic.elementi.join("-")} ×
            </button>
          ))
        )}
      </div>
    </div>
  );
}
