import { Component, useState } from 'react';
import App from './App';
import { appVersion, appReleaseDate } from './data/defaults';
import { createDemoData } from './data/demo';
import { readRecord } from './lib/webStorage';

class AppBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    if (this.state.failed) return <main className="webWelcome"><h1>Non riesco ad aprire l’app.</h1><p>L’archivio salvato non viene cancellato. Ricarica la pagina per riprovare.</p><button onClick={() => window.location.reload()}>Ricarica</button></main>;
    return this.props.children;
  }
}

export default function WebRoot() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const openLocal = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await readRecord('archive');
      if (data && (!Array.isArray(data.patients) || !Array.isArray(data.studios))) throw new Error('Archivio non leggibile.');
      setSession({ demo: false, initialData: data });
    } catch {
      setError('Non riesco a leggere l’archivio locale. Controlla che il browser permetta il salvataggio dei dati e riprova. I dati esistenti non sono stati sostituiti.');
    } finally { setLoading(false); }
  };
  if (session) return <AppBoundary><App key={session.demo ? 'demo' : 'local'} {...session} onExit={() => setSession(null)} /></AppBoundary>;
  return <main className="webWelcome">
    <header className="webBrand"><span className="webMark" aria-hidden="true">OP</span><span>Ortho Patients <small>Web · Versione {appVersion}</small></span></header>
    <div className="webIntro"><span className="webEyebrow">VERSIONE {appVersion} · {appReleaseDate}</span><h1>La tua ortodonzia,<br />nel browser.</h1><p>Agenda, pazienti e trattamenti. Apri il link e comincia, senza installare l’app.</p></div>
    <div className="webChoices">
      <section className="webChoice webDemoChoice"><span className="webStep">01 / ESPLORA</span><h2>Prova la demo</h2><p>Tre pazienti fittizi e gli appuntamenti di oggi, già pronti. Puoi modificare tutto e provare le funzioni.</p><button disabled={loading} onClick={() => setSession({ demo: true, initialData: createDemoData() })}>Entra nella demo <span aria-hidden="true">↗</span></button><small>La demo riparte da zero quando esci o ricarichi la pagina.</small></section>
      <section className="webChoice"><span className="webStep">02 / IL TUO ARCHIVIO</span><h2>Lavora su questo browser</h2><p>Crea o riapri il tuo archivio locale. Puoi anche importare un backup della versione Mac.</p><button className="webSecondary" disabled={loading} onClick={openLocal}>{loading ? 'Apertura…' : 'Apri archivio locale'} <span aria-hidden="true">→</span></button><small>I dati restano in questo browser. Nessuna sincronizzazione tra dispositivi.</small></section>
    </div>
    {error && <p className="webError" role="alert">{error}</p>}
    <footer className="webFooter"><p><strong>Come funziona il salvataggio?</strong> Schede e foto vengono conservate su questo dispositivo. Esporta un backup prima di cancellare i dati del browser o cambiare computer.</p><p>La password blocca l’apertura locale; non cifra l’archivio nel browser. Per la prova usa dati fittizi.</p></footer>
  </main>;
}
