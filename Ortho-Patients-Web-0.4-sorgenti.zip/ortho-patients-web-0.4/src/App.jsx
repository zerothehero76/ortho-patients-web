import { useCallback, useEffect, useMemo, useState } from "react";
import {
  appReleaseDate,
  appVersion,
  caseChecklistLabels,
  defaultCaseChecklist,
  defaultDiagnosis,
  defaultLaboratories,
  defaultLingualWireSequence,
  defaultStudios,
  defaultWireSequence,
  initialPatients
} from "./data/defaults";
import {
  addDays,
  ageFromDate,
  formatDateIT,
  getMonday,
  monthsBetweenDates,
  monthsLabel,
  weekdayLabel
} from "./lib/dateUtils";
import { createEmptyDiaryDraft } from "./lib/diaryUtils";
import { decryptBackupData, encryptBackupText, hashPassword, parseBackupJsonText } from "./lib/backupCrypto";
import { matchesSearchQuery } from "./lib/searchUtils";
import { getStoredSetting, storeSetting, saveArchive, getLocalSetting, setLocalSetting, requestArchivePersistence } from "./lib/webStorage";
import { mergeCollectionById, mergePatientForImport, normalizePatient } from "./lib/patientUtils";
import { agendaTimeline, appointmentReason, localDateISO } from "./lib/agendaUtils";
import { ElasticDiagram } from "./components/ElasticDiagram";
import { Badge, Button, Card, ScoreSlider } from "./components/ui";

export default function App({ demo = false, initialData = null, onExit }) {
  const [savedData] = useState(initialData);
  const readSetting = (key) => demo ? null : getLocalSetting(key);

  const savedStudios = Array.isArray(savedData?.studios) && savedData.studios.length ? savedData.studios : defaultStudios;
  const savedLaboratories = Array.isArray(savedData?.laboratories) && savedData.laboratories.length ? savedData.laboratories : defaultLaboratories;
  const savedPatients = Array.isArray(savedData?.patients)
    ? savedData.patients.map((patient) => normalizePatient(patient, savedStudios))
    : (demo ? initialPatients : []);

  const [activeTab, setActiveTab] = useState("agenda");
  const [studios, setStudios] = useState(savedStudios);
  const [laboratories, setLaboratories] = useState(savedLaboratories);
  const [patients, setPatients] = useState(savedPatients);
  const [selectedId, setSelectedId] = useState(savedData?.selectedId || savedPatients[0]?.id || initialPatients[0].id);
  const [wireSequence, setWireSequence] = useState(savedData?.wireSequence || defaultWireSequence);
  const [lingualWireSequence, setLingualWireSequence] = useState(savedData?.lingualWireSequence || defaultLingualWireSequence);
  const [newStudioName, setNewStudioName] = useState("");
  const [newLaboratoryName, setNewLaboratoryName] = useState("");
  const [filterStudio, setFilterStudio] = useState("all");
  const [patientSearch, setPatientSearch] = useState("");
  const [openDiaryEntryId, setOpenDiaryEntryId] = useState(null);
  const [showPatientSheet, setShowPatientSheet] = useState(false);
  const [showDiaryElastics, setShowDiaryElastics] = useState(false);
  const [importText, setImportText] = useState("");
  const [importPassword, setImportPassword] = useState("");
  const [icsEvents, setIcsEvents] = useState([]);
  const [icsSearches, setIcsSearches] = useState({});
  const [icsAssignments, setIcsAssignments] = useState({});
  const [agendaDate, setAgendaDate] = useState(() => localDateISO());
  const [agendaNow, setAgendaNow] = useState(() => new Date());

  useEffect(() => {
    const refreshClock = () => setAgendaNow(new Date());
    const timer = window.setInterval(refreshClock, 60000);
    window.addEventListener("focus", refreshClock);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("focus", refreshClock);
    };
  }, []);
  const [agendaView, setAgendaView] = useState("giorno");
  const [agendaItems, setAgendaItems] = useState(Array.isArray(savedData?.agendaItems) ? savedData.agendaItems : []);
  const [materialOrders, setMaterialOrders] = useState(Array.isArray(savedData?.materialOrders) ? savedData.materialOrders : []);
  const [showMaterialOrders, setShowMaterialOrders] = useState(false);
  const [showReceivedMaterials, setShowReceivedMaterials] = useState(false);
  const [materialStudioFilter, setMaterialStudioFilter] = useState("all");
  const [materialDraft, setMaterialDraft] = useState({
    nome: "",
    quantita: 1,
    studioId: savedStudios[0]?.id || defaultStudios[0].id,
    supplierId: savedLaboratories[0]?.id || defaultLaboratories[0].id,
    patientId: "",
    urgenza: "normale",
    note: ""
  });

  const [draftDiary, setDraftDiary] = useState(createEmptyDiaryDraft);
  const [autoDiaryEntryId, setAutoDiaryEntryId] = useState("");
  const [diaryDraftTouched, setDiaryDraftTouched] = useState(false);
  const [diaryAutosaveStatus, setDiaryAutosaveStatus] = useState("");

  const [newAgendaItem, setNewAgendaItem] = useState({
    ora: "09:00",
    patientId: "",
    motivo: ""
  });

  const [photoDraft, setPhotoDraft] = useState({
    data: new Date().toISOString().slice(0, 10),
    tipo: "Foto iniziali",
    diarioEntryId: "",
    note: "",
    photos: []
  });

  const [prescriptionDraft, setPrescriptionDraft] = useState({
    data: new Date().toISOString().slice(0, 10),
    laboratorioId: savedLaboratories[0]?.id || defaultLaboratories[0].id,
    testo: ""
  });
  const [photoSearchDate, setPhotoSearchDate] = useState("");
  const [diagnosisExportText, setDiagnosisExportText] = useState("");
  const [recallTreatmentFilter, setRecallTreatmentFilter] = useState("all");
  const [recallStudioFilter, setRecallStudioFilter] = useState("all");
  const [recallMonthFilter, setRecallMonthFilter] = useState("6");
  const [showExcludedRecall, setShowExcludedRecall] = useState(false);
  const [saveFileHandle, setSaveFileHandle] = useState(null);
  const [saveFileName, setSaveFileName] = useState("");
  const [authConfig, setAuthConfig] = useState(() => {
    try {
      return JSON.parse(readSetting("orthoPatientsAuth") || "null");
    } catch {
      return null;
    }
  });
  const [isUnlocked, setIsUnlocked] = useState(() => !readSetting("orthoPatientsAuth"));
  const [authDraft, setAuthDraft] = useState({
    password: "",
    confirmPassword: "",
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: ""
  });
  const [authMessage, setAuthMessage] = useState("");
  const [sessionPassword, setSessionPassword] = useState("");
  const [encryptBackups, setEncryptBackups] = useState(() => readSetting("orthoPatientsEncryptBackups") === "true");
  const [storageWarning, setStorageWarning] = useState("");
  const [paymentDraft, setPaymentDraft] = useState({
    rataIniziale: "",
    numeroRate: 3,
    durataTrattamento: 6,
    dataInizio: new Date().toISOString().slice(0, 10),
    scontoPercentuale: ""
  });
  const [quoteEstimateDraft, setQuoteEstimateDraft] = useState({
    spese: "",
    percentualeOrtodontista: "",
    percentualeSpeseStudio: "",
    durataMesi: "",
    ricavoMensile: ""
  });

  const selectedPatient = patients.find((p) => p.id === selectedId) || patients[0];
  const selectedStudio = studios.find((s) => s.id === selectedPatient?.studioId);
  const agendaReason = newAgendaItem.patientId === selectedPatient?.id
    ? newAgendaItem.motivo
    : appointmentReason(selectedPatient);

  useEffect(() => {
    if (demo || !authConfig) return;
    let active = true;
    saveArchive({ studios, laboratories, patients, selectedId, wireSequence, lingualWireSequence, agendaItems, materialOrders })
      .then(() => { if (active) setStorageWarning(""); })
      .catch(() => { if (active) setStorageWarning("Salvataggio nel browser non riuscito. Esporta subito un backup con Salva prima di chiudere la pagina."); });
    return () => { active = false; };
  }, [demo, authConfig, studios, laboratories, patients, selectedId, wireSequence, lingualWireSequence, agendaItems, materialOrders]);

  useEffect(() => {
    if (demo) return;
    let active = true;
    getStoredSetting("databaseFileHandle")
      .then((handle) => {
        if (!active || !handle) return;
        setSaveFileHandle(handle);
        setSaveFileName(handle.name || "File JSON selezionato");
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [demo]);

  useEffect(() => {
    if (demo || !isUnlocked || !authConfig) return undefined;
    let timeoutId;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        setIsUnlocked(false);
        setSessionPassword("");
        setAuthMessage("App bloccata per inattività.");
      }, 15 * 60 * 1000);
    };

    const events = ["mousemove", "mousedown", "keydown", "touchstart", "scroll"];
    events.forEach((eventName) => window.addEventListener(eventName, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach((eventName) => window.removeEventListener(eventName, resetTimer));
    };
  }, [demo, isUnlocked, authConfig]);

  useEffect(() => {
    if (demo) return;
    Promise.resolve().then(() => setLocalSetting("orthoPatientsEncryptBackups", encryptBackups ? "true" : "false"))
      .catch(() => setStorageWarning("Impossibile salvare le preferenze: controlla i permessi del browser."));
  }, [demo, encryptBackups]);

  const filteredPatients = useMemo(() => {
    return patients.filter((p) => {
      const matchesStudio = filterStudio === "all" || p.studioId === filterStudio;
      const text = `${p.nome} ${p.cognome} ${p.pseudonimo} ${p.email} ${p.telefono} ${p.codiceFiscale} ${p.indirizzo}`;
      const matchesSearch = matchesSearchQuery(text, patientSearch);
      return matchesStudio && matchesSearch;
    });
  }, [patients, filterStudio, patientSearch]);

  const updatePatient = (patch) => {
    setPatients((currentPatients) =>
      currentPatients.map((p) => p.id === selectedId ? { ...p, ...patch } : p)
    );
  };

  const updateDiagnosis = (patch) => {
    updatePatient({
      diagnosi: {
        ...(selectedPatient.diagnosi || defaultDiagnosis),
        ...patch
      }
    });
  };

  const updateTreatmentPlan = (patch) => {
    updatePatient({
      diagnosi: {
        ...(selectedPatient.diagnosi || defaultDiagnosis),
        pianoTerapeutico: {
          ...(selectedPatient.diagnosi?.pianoTerapeutico || defaultDiagnosis.pianoTerapeutico),
          ...patch
        }
      }
    });
  };

  const isFixedApplianceTreatment = (treatment) => ["fissa", "fissa_estetica", "linguale"].includes(treatment);

  const updateStudioCaseChecklist = (key, checked) => {
    updatePatient({
      studioCasoChecklist: {
        ...defaultCaseChecklist,
        ...(selectedPatient.studioCasoChecklist || {}),
        [key]: checked
      }
    });
  };

  const treatmentLabel = (treatment) => {
    const labels = {
      studio_caso: "Studio caso",
      fissa: "Fissa tradizionale",
      fissa_estetica: "Fissa estetica",
      linguale: "Linguale",
      allineatori: "Allineatori",
      intercettiva: "Intercettiva",
      contenzione: "Contenzione",
      perso: "Perso"
    };
    return labels[treatment] || String(treatment || "").replaceAll("_", " ");
  };

  const isActiveTreatment = (treatment) => ["fissa", "fissa_estetica", "linguale", "allineatori", "intercettiva"].includes(treatment);

  const patientMatchesRecallTreatment = (patient) => {
    if (recallTreatmentFilter === "all") return patient.trattamento !== "perso";
    if (recallTreatmentFilter === "active") return isActiveTreatment(patient.trattamento);
    return patient.trattamento === recallTreatmentFilter;
  };

  const deletePatient = (patientId) => {
    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;
    const patientName = `${patient.cognome || "Cognome"} ${patient.nome || "Nome"}`;
    const confirmed = window.confirm(`Cancellare definitivamente ${patientName}? Verranno rimossi anche gli appuntamenti in agenda collegati.`);
    if (!confirmed) return;

    const remainingPatients = patients.filter((p) => p.id !== patientId);
    setPatients(remainingPatients);
    setAgendaItems((currentItems) => currentItems.filter((item) => item.patientId !== patientId));
    setMaterialOrders((currentItems) => currentItems.map((item) => item.patientId === patientId ? { ...item, patientId: "" } : item));

    if (selectedId === patientId) {
      setSelectedId(remainingPatients[0]?.id || "");
      setShowPatientSheet(false);
      if (remainingPatients.length === 0) setActiveTab("agenda");
    }
  };

  const buildDiagnosisExport = () => {
    const d = selectedPatient?.diagnosi || defaultDiagnosis;
    const divergenceLabels = {
      normale: "normodivergente",
      ipodivergenza: "ipodivergente",
      normodivergente: "normodivergente",
      iperdivergenza: "iperdivergente",
      ipodivergente: "ipodivergente",
      iperdivergente: "iperdivergente"
    };
    const divergence = divergenceLabels[d.divergenza] || "divergenza non specificata";
    const growth = d.faseCrescita ? d.faseCrescita : "fase di crescita non specificata";
    const transversal = d.discrepanzaTrasversale === "si" ? "presenza di discrepanza trasversale" : "assenza di discrepanza trasversale segnalata";
    const agenesie = d.agenesieSovrannumerari ? d.agenesieSovrannumerari : "nessuna agenesia o sovrannumerario segnalato";
    const cc = d.cc ? d.cc : "non specificate";
    const durata = d.pianoTerapeutico?.durataPrevista ? d.pianoTerapeutico.durataPrevista : "da definire";
    const obiettivi = d.pianoTerapeutico?.obiettivi ? d.pianoTerapeutico.obiettivi : "da definire";

    const text = `Paziente: ${selectedPatient.cognome || ""} ${selectedPatient.nome || ""}

Diagnosi ortodontica:
Malocclusione di classe scheletrica ${d.classeScheletrica || "—"} e classe dentale ${d.classeDentale || "—"}, con pattern ${divergence}.
Fase di crescita: ${growth}.
Quadro clinico principale / CC: ${cc}.
Discrepanza trasversale: ${transversal}.
Agenesie / sovrannumerari: ${agenesie}.
${d.notaLibera ? `Note aggiuntive: ${d.notaLibera}.
` : ""}
Piano terapeutico:
Durata prevista: ${durata}.
Obiettivi terapeutici: ${obiettivi}.`;

    setDiagnosisExportText(text);
  };

  const copyDiagnosisExport = async () => {
    if (!diagnosisExportText) return;
    try {
      await navigator.clipboard.writeText(diagnosisExportText);
      alert("Testo diagnosi copiato negli appunti.");
    } catch {
      alert("Copia automatica non riuscita: seleziona e copia il testo manualmente.");
    }
  };

  const formatCurrencyIT = (value) => {
    const number = Number(value);
    if (!Number.isFinite(number)) return "€ 0,00";
    return new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(number);
  };

  const romanNumeral = (value) => {
    const numerals = [
      ["X", 10],
      ["IX", 9],
      ["V", 5],
      ["IV", 4],
      ["I", 1]
    ];
    let remaining = Number(value);
    let result = "";
    numerals.forEach(([symbol, amount]) => {
      while (remaining >= amount) {
        result += symbol;
        remaining -= amount;
      }
    });
    return result || String(value);
  };

  const splitAmountIntoRates = (amount, count) => {
    const totalCents = Math.max(Math.round(Number(amount || 0) * 100), 0);
    const rateCount = Math.max(Number(count || 0), 0);
    if (!rateCount) return [];
    const base = Math.floor(totalCents / rateCount);
    const remainder = totalCents % rateCount;
    return Array.from({ length: rateCount }, (_, index) => (base + (index < remainder ? 1 : 0)) / 100);
  };

  const getPaymentDueMonths = (rateCount, durationMonths, startDate) => {
    const count = Math.max(Math.round(Number(rateCount || 0)), 1);
    const duration = Math.max(Number(durationMonths || 0), 0);
    const safeStartDate = startDate || new Date().toISOString().slice(0, 10);
    const [startYear, startMonth] = String(safeStartDate).split("-").map(Number);

    return Array.from({ length: count }, (_, index) => {
      const monthOffset = index === 0 ? 0 : Math.max(index, Math.round((index * duration) / count));
      const dueDate = new Date(startYear, startMonth - 1 + monthOffset, 1);
      return new Intl.DateTimeFormat("it-IT", { month: "long", year: "numeric" }).format(dueDate).toUpperCase();
    });
  };

  const getPaymentSummary = () => {
    const total = Math.max(Number(selectedPatient?.preventivo || 0), 0);
    const initial = Math.max(Number(paymentDraft.rataIniziale || 0), 0);
    const rateCount = Math.max(Math.round(Number(paymentDraft.numeroRate || 0)), 1);
    const additionalRateCount = Math.max(rateCount - 1, 0);
    const durationMonths = Math.max(Number(paymentDraft.durataTrattamento || 0), 0);
    const discountPercent = Math.max(Number(paymentDraft.scontoPercentuale || 0), 0);
    const remaining = Math.max(total - initial, 0);
    const rates = splitAmountIntoRates(remaining, additionalRateCount);
    const discountedTotal = total * (1 - Math.min(discountPercent, 100) / 100);
    const discountedRemaining = Math.max(discountedTotal - initial, 0);
    const discountedRates = splitAmountIntoRates(discountedRemaining, additionalRateCount);
    const dueMonths = getPaymentDueMonths(rateCount, durationMonths, paymentDraft.dataInizio);

    const lines = [
      `Preventivo: ${formatCurrencyIT(total)}`,
      `Durata trattamento: ${durationMonths} mesi`,
      "",
      "Rate:",
      `I RATA (INIZIALE) - ${dueMonths[0]}: ${formatCurrencyIT(initial)}`,
      ...rates.map((rate, index) => `${romanNumeral(index + 2)} RATA - ${dueMonths[index + 1]}: ${formatCurrencyIT(rate)}`),
      "",
      "Prezzi scontati:",
      discountPercent ? `Sconto applicato: ${discountPercent}%` : "Sconto applicato: non impostato",
      `Preventivo scontato: ${formatCurrencyIT(discountedTotal)}`,
      `Residuo dopo rata iniziale: ${formatCurrencyIT(discountedRemaining)}`,
      `I RATA (INIZIALE) - ${dueMonths[0]}: ${formatCurrencyIT(initial)}`,
      ...discountedRates.map((rate, index) => `${romanNumeral(index + 2)} RATA SCONTATA - ${dueMonths[index + 1]}: ${formatCurrencyIT(rate)}`)
    ];

    return lines.join("\n");
  };

  const copyPaymentSummary = async () => {
    try {
      await navigator.clipboard.writeText(getPaymentSummary());
      alert("Riepilogo preventivo copiato negli appunti.");
    } catch {
      alert("Copia automatica non riuscita: seleziona e copia il testo manualmente.");
    }
  };

  const getQuoteEstimate = () => {
    const hasAllInputs = ["spese", "percentualeOrtodontista", "percentualeSpeseStudio", "durataMesi", "ricavoMensile"]
      .every((key) => quoteEstimateDraft[key] !== "");
    if (!hasAllInputs) return { incomplete: true };

    const expenses = Math.max(Number(quoteEstimateDraft.spese || 0), 0);
    const orthodontistPercent = Math.min(Math.max(Number(quoteEstimateDraft.percentualeOrtodontista || 0), 0), 100);
    const studioExpensePercent = Math.min(Math.max(Number(quoteEstimateDraft.percentualeSpeseStudio || 0), 0), 100);
    const durationMonths = Math.max(Math.round(Number(quoteEstimateDraft.durataMesi || 0)), 0);
    const monthlyRevenue = Math.max(Number(quoteEstimateDraft.ricavoMensile || 0), 0);
    const orthodontistShare = orthodontistPercent / 100;
    const studioRevenueShare = 1 - orthodontistShare;
    const studioExpenses = expenses * studioExpensePercent / 100;
    const orthodontistExpenses = expenses - studioExpenses;
    const orthodontistMinimum = orthodontistExpenses > 0
      ? (orthodontistShare > 0 ? orthodontistExpenses / orthodontistShare : Number.POSITIVE_INFINITY)
      : 0;
    const studioMinimum = studioExpenses > 0
      ? (studioRevenueShare > 0 ? studioExpenses / studioRevenueShare : Number.POSITIVE_INFINITY)
      : 0;
    const estimate = Math.max(orthodontistMinimum, studioMinimum);
    const desiredOrthodontistRevenue = monthlyRevenue * durationMonths;
    const orthodontistTargetMinimum = orthodontistExpenses + desiredOrthodontistRevenue > 0
      ? (orthodontistShare > 0
        ? (orthodontistExpenses + desiredOrthodontistRevenue) / orthodontistShare
        : Number.POSITIVE_INFINITY)
      : 0;
    const finalEstimate = Math.max(orthodontistTargetMinimum, studioMinimum);

    if (!Number.isFinite(estimate) || !Number.isFinite(finalEstimate)) {
      return {
        valid: false,
        message: "Percentuali incompatibili con la ripartizione delle spese."
      };
    }

    const orthodontistAmount = finalEstimate * orthodontistShare;
    const studioAmount = finalEstimate * studioRevenueShare;

    return {
      valid: true,
      estimate,
      finalEstimate,
      monthly: durationMonths ? finalEstimate / durationMonths : 0,
      monthlyRevenue,
      desiredOrthodontistRevenue,
      orthodontistAmount,
      orthodontistNetRevenue: orthodontistAmount - orthodontistExpenses,
      studioAmount,
      studioNetRevenue: studioAmount - studioExpenses,
      orthodontistExpenses,
      studioExpenses,
      durationMonths
    };
  };

  const addPatient = () => {
    const newPatient = normalizePatient({
      id: `p-${Date.now()}`,
      studioId: studios[0]?.id || "studio-1"
    }, studios);
    setPatients([newPatient, ...patients]);
    setSelectedId(newPatient.id);
    setShowPatientSheet(true);
  };

  const updateStudio = (studioId, patch) => {
    setStudios((currentStudios) => currentStudios.map((studio) => studio.id === studioId ? { ...studio, ...patch } : studio));
  };

  const addStudio = () => {
    if (!newStudioName.trim()) return;
    setStudios([...studios, { id: `studio-${Date.now()}`, nome: newStudioName.trim(), indirizzo: "", telefono: "", email: "" }]);
    setNewStudioName("");
  };

  const deleteStudio = (studioId) => {
    setStudios((currentStudios) => {
      if (currentStudios.length <= 1) return currentStudios;
      const remainingStudios = currentStudios.filter((studio) => studio.id !== studioId);
      const fallbackStudioId = remainingStudios[0]?.id;
      setPatients((currentPatients) => currentPatients.map((patient) => patient.studioId === studioId ? { ...patient, studioId: fallbackStudioId } : patient));
      setAgendaItems((currentItems) => currentItems.map((item) => item.studioId === studioId ? { ...item, studioId: fallbackStudioId } : item));
      setMaterialOrders((currentItems) => currentItems.map((item) => item.studioId === studioId ? { ...item, studioId: fallbackStudioId } : item));
      setNewAgendaItem((current) => current.studioId === studioId ? { ...current, studioId: fallbackStudioId } : current);
      setMaterialDraft((current) => current.studioId === studioId ? { ...current, studioId: fallbackStudioId } : current);
      return remainingStudios;
    });
  };

  const updateLaboratory = (laboratoryId, patch) => {
    setLaboratories((currentLaboratories) =>
      currentLaboratories.map((laboratory) => laboratory.id === laboratoryId ? { ...laboratory, ...patch } : laboratory)
    );
  };

  const addLaboratory = () => {
    if (!newLaboratoryName.trim()) return;
    const newLaboratory = { id: `lab-${Date.now()}`, nome: newLaboratoryName.trim() };
    setLaboratories([...laboratories, newLaboratory]);
    setNewLaboratoryName("");
    setPrescriptionDraft((current) => ({ ...current, laboratorioId: newLaboratory.id }));
    setMaterialDraft((current) => ({ ...current, supplierId: newLaboratory.id }));
  };

  const deleteLaboratory = (laboratoryId) => {
    setLaboratories((currentLaboratories) => {
      if (currentLaboratories.length <= 1) return currentLaboratories;
      const remainingLaboratories = currentLaboratories.filter((laboratory) => laboratory.id !== laboratoryId);
      const fallbackLaboratoryId = remainingLaboratories[0]?.id;
      setPatients((currentPatients) => currentPatients.map((patient) => ({
        ...patient,
        prescrizioni: (patient.prescrizioni || []).map((rx) =>
          rx.laboratorioId === laboratoryId ? { ...rx, laboratorioId: fallbackLaboratoryId } : rx
        )
      })));
      setPrescriptionDraft((current) => current.laboratorioId === laboratoryId ? { ...current, laboratorioId: fallbackLaboratoryId } : current);
      setMaterialOrders((currentItems) => currentItems.map((item) => item.supplierId === laboratoryId ? { ...item, supplierId: fallbackLaboratoryId } : item));
      setMaterialDraft((current) => current.supplierId === laboratoryId ? { ...current, supplierId: fallbackLaboratoryId } : current);
      return remainingLaboratories;
    });
  };

  const activeWireSequence = selectedPatient?.trattamento === "linguale" ? lingualWireSequence : wireSequence;

  const getAlignerSchedule = useCallback((delivery) => {
    const from = Number(delivery?.da);
    const to = Number(delivery?.a);
    const interval = Number(delivery?.cambioGiorni);
    const startDate = delivery?.dataInizio || draftDiary.data;
    const firstAlignerDouble = Boolean(delivery?.aligner1Doppio) && from === 1;

    if (!from || !to || !interval || !startDate || to < from) return { rows: [], coveredUntil: "" };

    const start = new Date(`${startDate}T00:00:00`);
    const rows = [];
    let cursor = new Date(start);

    for (let aligner = from; aligner <= to; aligner++) {
      const startAligner = new Date(cursor);
      const duration = firstAlignerDouble && aligner === 1 ? interval * 2 : interval;

      const endAligner = new Date(startAligner);
      endAligner.setDate(startAligner.getDate() + duration - 1);

      rows.push({
        aligner,
        start: startAligner.toISOString().slice(0, 10),
        end: endAligner.toISOString().slice(0, 10)
      });

      cursor = new Date(startAligner);
      cursor.setDate(startAligner.getDate() + duration);
    }

    return { rows, coveredUntil: rows[rows.length - 1]?.end || "" };
  }, [draftDiary.data]);

  const getLatestAlignerDelivery = (patient) => {
    const deliveries = (patient?.diario || [])
      .filter((entry) => entry.alignerDelivery?.schedule?.length > 0)
      .sort((a, b) => `${b.data || ""}`.localeCompare(`${a.data || ""}`));
    return deliveries[0] || null;
  };

  const getExpectedAlignerInfo = (patient) => {
    const deliveryEntry = getLatestAlignerDelivery(patient);
    const schedule = deliveryEntry?.alignerDelivery?.schedule || [];
    if (!deliveryEntry || schedule.length === 0) return null;

    const today = new Date().toISOString().slice(0, 10);
    const current = schedule.find((row) => row.start <= today && row.end >= today);
    const first = schedule[0];
    const last = schedule[schedule.length - 1];

    if (current) return { deliveryEntry, row: current, status: "in corso" };
    if (today < first.start) return { deliveryEntry, row: first, status: "non ancora iniziato" };
    return { deliveryEntry, row: last, status: "oltre calendario" };
  };

  const exportAlignerCalendarTxt = () => {
    const deliveryEntry = getLatestAlignerDelivery(selectedPatient);
    const schedule = deliveryEntry?.alignerDelivery?.schedule || [];

    if (!deliveryEntry || schedule.length === 0) {
      alert("Nessun calendario allineatori da esportare per questo paziente.");
      return;
    }

    const delivery = deliveryEntry.alignerDelivery;
    const patientName = `${selectedPatient.cognome || "Cognome"} ${selectedPatient.nome || "Nome"}`.trim();
    const lines = [
      `Calendario allineatori - ${patientName}`,
      selectedPatient.pseudonimo ? `Paziente: ${selectedPatient.pseudonimo}` : "",
      "",
      `Consegna del ${formatDateIT(deliveryEntry.data)}`,
      `Aligner consegnati: ${delivery.da || "?"} - ${delivery.a || "?"}`,
      `Cambio ogni: ${delivery.cambioGiorni || "?"} giorni`,
      delivery.aligner1Doppio ? "Aligner 1: durata doppia" : "",
      `Inizio: ${formatDateIT(delivery.dataInizio)}`,
      `Coperto fino a: ${formatDateIT(delivery.coveredUntil)}`,
      "",
      "Progressione:",
      ...schedule.map((row) => `Aligner ${row.aligner}: dal ${formatDateIT(row.start)} al ${formatDateIT(row.end)}`)
    ].filter((line, index) => line || index === 2 || index === 8);

    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const safeName = patientName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "paziente";
    link.href = url;
    link.download = `calendario-aligner-${safeName}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const updateDiaryDraft = (patch) => {
    if (!autoDiaryEntryId && selectedPatient?.id) setAutoDiaryEntryId(`d-${selectedPatient.id}-${Date.now()}`);
    setDraftDiary((current) => ({ ...current, ...patch }));
    setDiaryDraftTouched(true);
    setDiaryAutosaveStatus("Modifiche in attesa...");
  };

  const updateDiaryDeliveryDraft = (patch) => {
    if (!autoDiaryEntryId && selectedPatient?.id) setAutoDiaryEntryId(`d-${selectedPatient.id}-${Date.now()}`);
    setDraftDiary((current) => ({ ...current, alignerDelivery: { ...current.alignerDelivery, ...patch } }));
    setDiaryDraftTouched(true);
    setDiaryAutosaveStatus("Modifiche in attesa...");
  };

  const resetDiaryDraft = useCallback(() => {
    setDraftDiary(createEmptyDiaryDraft());
    setAutoDiaryEntryId("");
    setDiaryDraftTouched(false);
    setDiaryAutosaveStatus("");
  }, []);

  const selectDiaryEntryForEdit = (entry) => {
    setOpenDiaryEntryId(entry.id);
    setAutoDiaryEntryId(entry.id);
    setDraftDiary({
      arcoSup: entry.arcoSup || "",
      arcoInf: entry.arcoInf || "",
      arcoNote: entry.arcoNote || "",
      aligner: entry.aligner || "",
      alignerDelivery: {
        da: entry.alignerDelivery?.da || "",
        a: entry.alignerDelivery?.a || "",
        cambioGiorni: entry.alignerDelivery?.cambioGiorni || 7,
        dataInizio: entry.alignerDelivery?.dataInizio || entry.data || new Date().toISOString().slice(0, 10),
        aligner1Doppio: Boolean(entry.alignerDelivery?.aligner1Doppio)
      },
      data: entry.data || new Date().toISOString().slice(0, 10),
      tipo: entry.tipo || "Controllo ortodontico",
      azione: entry.azione || "",
      foto: Boolean(entry.foto),
      elastici: Array.isArray(entry.elastici) ? entry.elastici : []
    });
    setDiaryDraftTouched(false);
    setDiaryAutosaveStatus("Appuntamento caricato nel modulo a sinistra.");
  };

  const diaryDraftHasContent = useCallback(() => {
    const today = new Date().toISOString().slice(0, 10);
    return Boolean(
      draftDiary.azione.trim()
      || draftDiary.foto
      || draftDiary.elastici.length
      || draftDiary.arcoSup
      || draftDiary.arcoInf
      || draftDiary.arcoNote
      || draftDiary.aligner
      || draftDiary.alignerDelivery.da
      || draftDiary.alignerDelivery.a
      || draftDiary.tipo !== "Controllo ortodontico"
      || draftDiary.data !== today
    );
  }, [draftDiary]);

  const upsertDiaryFromDraft = useCallback(({ resetAfter = false } = {}) => {
    if (!selectedPatient || !diaryDraftHasContent()) return false;
    const isFixedTreatment = isFixedApplianceTreatment(selectedPatient.trattamento);
    const sequence = selectedPatient.trattamento === "linguale" ? lingualWireSequence : wireSequence;
    const isAlignerDelivery = selectedPatient.trattamento === "allineatori" && draftDiary.tipo === "Consegna allineatori";
    const alignerSchedule = getAlignerSchedule(draftDiary.alignerDelivery);
    const entryId = autoDiaryEntryId;
    if (!entryId) return false;
    const lastDiaryWire = (arch) => {
      const field = arch === "sup" ? "arcoSup" : "arcoInf";
      const entries = (selectedPatient.diario || [])
        .filter((item) => item[field])
        .sort((a, b) => `${b.data || ""}`.localeCompare(`${a.data || ""}`));
      const index = arch === "sup" ? selectedPatient.arcoSupIndex : selectedPatient.arcoInfIndex;
      return entries[0]?.[field] || sequence[index || 0] || "---";
    };

    const entry = {
      id: entryId,
      data: draftDiary.data || new Date().toISOString().slice(0, 10),
      tipo: draftDiary.tipo,
      azione: draftDiary.azione || "Controllo eseguito.",
      igiene: selectedPatient.igiene,
      compliance: selectedPatient.compliance,
      arcoSup: isFixedTreatment ? draftDiary.arcoSup || lastDiaryWire("sup") || sequence[0] || "---" : null,
      arcoInf: isFixedTreatment ? draftDiary.arcoInf || lastDiaryWire("inf") || sequence[0] || "---" : null,
      arcoNote: isFixedTreatment ? draftDiary.arcoNote : "",
      aligner: selectedPatient.trattamento === "allineatori" ? (isAlignerDelivery ? draftDiary.alignerDelivery?.a : draftDiary.aligner) || selectedPatient.alignerCorrente : null,
      alignerDelivery: isAlignerDelivery ? {
        ...draftDiary.alignerDelivery,
        schedule: alignerSchedule.rows,
        coveredUntil: alignerSchedule.coveredUntil
      } : null,
      foto: draftDiary.foto,
      elastici: draftDiary.elastici
    };

    setPatients((currentPatients) => currentPatients.map((patient) => {
      if (patient.id !== selectedId) return patient;
      const currentDiary = patient.diario || [];
      const hasEntry = currentDiary.some((item) => item.id === entry.id);
      const nextPatient = {
        ...patient,
        diario: hasEntry
          ? currentDiary.map((item) => item.id === entry.id ? entry : item)
          : [entry, ...currentDiary]
      };

      if (entry.foto && !(patient.photoSessions || []).some((session) => session.diarioEntryId === entry.id)) {
        nextPatient.photoSessions = [
          {
            id: `ps-${entry.id}`,
            data: entry.data,
            tipo: "Foto controllo",
            diarioEntryId: entry.id,
            note: "",
            photos: []
          },
          ...(patient.photoSessions || [])
        ];
      }

      if (isFixedTreatment) {
        nextPatient.arcoSupIndex = Math.max(sequence.indexOf(entry.arcoSup), 0);
        nextPatient.arcoInfIndex = Math.max(sequence.indexOf(entry.arcoInf), 0);
      }

      if (patient.trattamento === "allineatori" && entry.aligner) {
        nextPatient.alignerCorrente = Number(entry.aligner);
      }

      return nextPatient;
    }));

    setAutoDiaryEntryId(entry.id);
    setOpenDiaryEntryId(entry.id);
    setDiaryDraftTouched(false);
    setDiaryAutosaveStatus(`Diario salvato automaticamente alle ${new Intl.DateTimeFormat("it-IT", { hour: "2-digit", minute: "2-digit" }).format(new Date())}`);
    if (resetAfter) resetDiaryDraft();
    return true;
  }, [autoDiaryEntryId, diaryDraftHasContent, draftDiary, getAlignerSchedule, lingualWireSequence, resetDiaryDraft, selectedId, selectedPatient, wireSequence]);

  useEffect(() => {
    const timeoutId = window.setTimeout(resetDiaryDraft, 0);
    return () => window.clearTimeout(timeoutId);
  }, [selectedId, resetDiaryDraft]);

  useEffect(() => {
    if (activeTab !== "diario" || !selectedPatient || !diaryDraftTouched || !diaryDraftHasContent()) return undefined;
    const timeoutId = window.setTimeout(() => {
      setDiaryAutosaveStatus("Salvataggio diario...");
      upsertDiaryFromDraft();
    }, 900);
    return () => window.clearTimeout(timeoutId);
  }, [activeTab, selectedPatient, selectedId, draftDiary, diaryDraftTouched, autoDiaryEntryId, diaryDraftHasContent, upsertDiaryFromDraft]);

  const deleteDiaryEntry = (entryId) => {
    updatePatient({ diario: (selectedPatient.diario || []).filter((entry) => entry.id !== entryId) });
    if (autoDiaryEntryId === entryId) resetDiaryDraft();
  };

  const getLastPhotoDate = (patient) => {
    const diaryPhotoDates = (patient?.diario || []).filter((entry) => entry.foto).map((entry) => entry.data);
    const sessionPhotoDates = (patient?.photoSessions || []).map((session) => session.data);
    const allDates = [...diaryPhotoDates, ...sessionPhotoDates].filter(Boolean).sort((a, b) => b.localeCompare(a));
    return allDates[0] || "mai";
  };

  const getLastAppointment = (patient) => {
    const entries = (patient?.diario || []).map((entry) => entry.data).filter(Boolean).sort((a, b) => b.localeCompare(a));
    return entries[0] || "mai";
  };

  const getNextAppointment = (patientId) => {
    const today = new Date().toISOString().slice(0, 10);
    const futureItems = agendaItems
      .filter((item) => item.patientId === patientId && item.data >= today)
      .sort((a, b) => `${a.data} ${a.ora}`.localeCompare(`${b.data} ${b.ora}`));
    return futureItems[0] || null;
  };

  const getPatientAlignerCoverage = (patient) => {
    const dates = (patient?.diario || []).map((entry) => entry.alignerDelivery?.coveredUntil).filter(Boolean).sort((a, b) => b.localeCompare(a));
    return dates[0] || "";
  };

  const getCurrentWire = (patient, arch) => {
    const sequence = patient?.trattamento === "linguale" ? lingualWireSequence : wireSequence;
    const index = arch === "sup" ? patient?.arcoSupIndex : patient?.arcoInfIndex;
    return sequence[index || 0] || "---";
  };

  const getLastDiaryWire = (patient, arch) => {
    const field = arch === "sup" ? "arcoSup" : "arcoInf";
    const entries = (patient?.diario || [])
      .filter((entry) => entry[field])
      .sort((a, b) => `${b.data || ""}`.localeCompare(`${a.data || ""}`));
    return entries[0]?.[field] || getCurrentWire(patient, arch);
  };

  const addAgendaItem = () => {
    const patientIdForAgenda = selectedPatient?.id;
    if (!newAgendaItem.ora || !patientIdForAgenda || !selectedPatient?.studioId) return;
    setAgendaItems([
      ...agendaItems,
      {
        id: `a-${Date.now()}`,
        data: agendaDate,
        ora: newAgendaItem.ora,
        patientId: patientIdForAgenda,
        studioId: selectedPatient.studioId,
        motivo: agendaReason
      }
    ].sort((a, b) => `${a.data} ${a.ora}`.localeCompare(`${b.data} ${b.ora}`)));
  };

  const deleteAgendaItem = (id) => {
    setAgendaItems(agendaItems.filter((item) => item.id !== id));
  };

  const updateAgendaItem = (id, patch) => {
    setAgendaItems((currentItems) =>
      currentItems
        .map((item) => item.id === id ? { ...item, ...patch } : item)
        .sort((a, b) => `${a.data} ${a.ora}`.localeCompare(`${b.data} ${b.ora}`))
    );
  };

  const addMaterialOrder = () => {
    if (!materialDraft.nome.trim() || !materialDraft.studioId || !materialDraft.supplierId) return;
    setMaterialOrders((currentItems) => [{
      id: `material-${Date.now()}`,
      createdAt: new Date().toISOString(),
      stato: "da_ordinare",
      ...materialDraft,
      nome: materialDraft.nome.trim(),
      quantita: Math.max(Math.round(Number(materialDraft.quantita || 1)), 1),
      note: materialDraft.note.trim()
    }, ...currentItems]);
    setMaterialDraft((current) => ({ ...current, nome: "", quantita: 1, patientId: "", urgenza: "normale", note: "" }));
  };

  const updateMaterialOrder = (id, patch) => {
    setMaterialOrders((currentItems) => currentItems.map((item) => item.id === id ? { ...item, ...patch } : item));
  };

  const deleteMaterialOrder = (id) => {
    setMaterialOrders((currentItems) => currentItems.filter((item) => item.id !== id));
  };

  const visibleMaterialOrders = materialOrders
    .filter((item) => materialStudioFilter === "all" || item.studioId === materialStudioFilter)
    .filter((item) => showReceivedMaterials || item.stato !== "ricevuto")
    .sort((a, b) => {
      if (a.stato === "ricevuto" && b.stato !== "ricevuto") return 1;
      if (a.stato !== "ricevuto" && b.stato === "ricevuto") return -1;
      if (a.urgenza === "urgente" && b.urgenza !== "urgente") return -1;
      if (a.urgenza !== "urgente" && b.urgenza === "urgente") return 1;
      return `${b.createdAt || ""}`.localeCompare(`${a.createdAt || ""}`);
    });

  const dayAgenda = agendaItems.filter((item) => item.data === agendaDate).sort((a, b) => a.ora.localeCompare(b.ora));

  const dayPrescriptions = patients
    .flatMap((patient) => (patient.prescrizioni || []).map((rx) => ({ ...rx, patient })))
    .filter((rx) => rx.data === agendaDate)
    .sort((a, b) => `${a.patient.cognome} ${a.patient.nome}`.localeCompare(`${b.patient.cognome} ${b.patient.nome}`));

  const weekStart = getMonday(agendaDate);
  const weekDays = Array.from({ length: 7 }, (_, index) => addDays(weekStart, index));
  const weekAgendaByDate = weekDays.map((date) => {
    const appointments = agendaItems
      .filter((item) => item.data === date)
      .sort((a, b) => a.ora.localeCompare(b.ora));
    const prescriptions = patients
      .flatMap((patient) => (patient.prescrizioni || []).map((rx) => ({ ...rx, patient })))
      .filter((rx) => rx.data === date)
      .sort((a, b) => `${a.patient.cognome} ${a.patient.nome}`.localeCompare(`${b.patient.cognome} ${b.patient.nome}`));
    return { date, appointments, prescriptions };
  });

  const recallItems = patients
    .map((patient) => {
      const lastAppointment = getLastAppointment(patient);
      const monthsSinceLastAppointment = monthsBetweenDates(lastAppointment);
      const isNeverSeen = lastAppointment === "mai";
      return {
        patient,
        lastAppointment,
        monthsSinceLastAppointment,
        isNeverSeen,
        sortValue: isNeverSeen ? Number.POSITIVE_INFINITY : monthsSinceLastAppointment ?? -1
      };
    })
    .filter(({ patient }) => patientMatchesRecallTreatment(patient))
    .filter(({ patient }) => recallStudioFilter === "all" || patient.studioId === recallStudioFilter)
    .filter(({ patient }) => showExcludedRecall || !patient.esclusoRecall)
    .filter(({ monthsSinceLastAppointment, isNeverSeen }) => {
      if (recallMonthFilter === "all") return true;
      const threshold = Number(recallMonthFilter);
      return isNeverSeen || (monthsSinceLastAppointment !== null && monthsSinceLastAppointment >= threshold);
    })
    .sort((a, b) => b.sortValue - a.sortValue || `${a.patient.cognome} ${a.patient.nome}`.localeCompare(`${b.patient.cognome} ${b.patient.nome}`));

  const compressImage = (file, maxSize = 700, quality = 0.5) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve({
            id: `photo-${Date.now()}-${Math.random().toString(16).slice(2)}`,
            name: file.name,
            type: file.type,
            size: file.size,
            dataUrl: canvas.toDataURL("image/jpeg", quality)
          });
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const addPhotosToDraft = async (files) => {
    const compressed = await Promise.all(Array.from(files).map((file) => compressImage(file)));
    setPhotoDraft((current) => ({ ...current, photos: [...current.photos, ...compressed] }));
  };

  const savePhotoSession = () => {
    if (!selectedPatient || (!photoDraft.note.trim() && !photoDraft.photos.length && !photoDraft.diarioEntryId)) return;
    const session = {
      id: `ps-${Date.now()}`,
      data: photoDraft.data,
      tipo: photoDraft.tipo,
      diarioEntryId: photoDraft.diarioEntryId,
      note: photoDraft.note,
      photos: photoDraft.photos
    };
    updatePatient({ photoSessions: [session, ...(selectedPatient.photoSessions || [])] });
    setPhotoDraft({
      data: new Date().toISOString().slice(0, 10),
      tipo: "Foto controllo",
      diarioEntryId: "",
      note: "",
      photos: []
    });
  };

  const deletePhotoSession = (sessionId) => {
    updatePatient({ photoSessions: (selectedPatient.photoSessions || []).filter((session) => session.id !== sessionId) });
  };

  const updatePhotoSession = (patientId, sessionId, patch) => {
    setPatients((currentPatients) => currentPatients.map((patient) => {
      if (patient.id !== patientId) return patient;
      return {
        ...patient,
        photoSessions: (patient.photoSessions || []).map((session) =>
          session.id === sessionId ? { ...session, ...patch } : session
        )
      };
    }));
  };

  const exportPhotoIndexTxt = () => {
    const sessions = selectedPatient?.photoSessions || [];
    if (sessions.length === 0) {
      alert("Nessun set fotografico da esportare per questo paziente.");
      return;
    }

    const patientName = `${selectedPatient.cognome || "Cognome"} ${selectedPatient.nome || "Nome"}`.trim();
    const lines = [
      `Indice foto - ${patientName}`,
      selectedPatient.pseudonimo ? `Paziente: ${selectedPatient.pseudonimo}` : "",
      "",
      ...sessions.map((session) => {
        const linkedEntry = (selectedPatient.diario || []).find((entry) => entry.id === session.diarioEntryId);
        return [
          `${formatDateIT(session.data)} - ${session.tipo || "Set fotografico"}`,
          linkedEntry ? `Appuntamento collegato: ${formatDateIT(linkedEntry.data)} - ${linkedEntry.tipo}` : "",
          session.note ? `Note: ${session.note}` : "",
          session.photos?.length ? `Anteprime salvate: ${session.photos.length}` : "",
          ""
        ].filter(Boolean).join("\n");
      })
    ].filter((line, index) => line || index === 2);

    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const safeName = patientName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "paziente";
    link.href = url;
    link.download = `indice-foto-${safeName}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportPrescriptionTxt = (rx) => {
    if (!selectedPatient || !rx) return;
    const laboratory = laboratories.find((lab) => lab.id === rx.laboratorioId);
    const studio = studios.find((s) => s.id === selectedPatient.studioId);
    const patientName = `${selectedPatient.cognome || "Cognome"} ${selectedPatient.nome || "Nome"}`.trim();
    const lines = [
      `Paziente: ${patientName}`,
      selectedPatient.pseudonimo ? `Pseudonimo: ${selectedPatient.pseudonimo}` : "",
      "",
      `Data di consegna: ${formatDateIT(rx.data)}`,
      `Laboratorio: ${laboratory?.nome || rx.laboratorioNome || "Non specificato"}`,
      `Studio: ${studio?.nome || "Studio non indicato"}`,
      `Tipo di apparecchio: ${rx.testo || "Non specificato"}`
    ].filter((line, index) => line || index === 2);

    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const safePatient = patientName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "paziente";
    link.href = url;
    link.download = `prescrizione-apparecchio-${safePatient}-${rx.data || new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const addPrescription = () => {
    if (!prescriptionDraft.testo.trim()) return;
    const laboratory = laboratories.find((lab) => lab.id === prescriptionDraft.laboratorioId) || laboratories[0] || defaultLaboratories[0];
    updatePatient({
      prescrizioni: [
        {
          id: `rx-${Date.now()}`,
          data: prescriptionDraft.data,
          laboratorioId: laboratory.id,
          laboratorioNome: laboratory.nome,
          testo: prescriptionDraft.testo.trim()
        },
        ...(selectedPatient.prescrizioni || [])
      ]
    });
    setPrescriptionDraft({ data: new Date().toISOString().slice(0, 10), laboratorioId: laboratory.id, testo: "" });
  };

  const deletePrescription = (id) => {
    updatePatient({ prescrizioni: (selectedPatient.prescrizioni || []).filter((rx) => rx.id !== id) });
  };

  const updatePrescriptionStatus = (patientId, prescriptionId, patch) => {
    setPatients((currentPatients) => currentPatients.map((patient) => {
      if (patient.id !== patientId) return patient;
      return {
        ...patient,
        prescrizioni: (patient.prescrizioni || []).map((rx) => rx.id === prescriptionId ? { ...rx, ...patch } : rx)
      };
    }));
  };

  const photoSearchResults = patients.flatMap((patient) =>
    (patient.photoSessions || [])
      .filter((session) => !photoSearchDate || session.data === photoSearchDate)
      .map((session) => ({ patient, session }))
  ).sort((a, b) => `${b.session.data}`.localeCompare(`${a.session.data}`));

  const isCompactEmpty = (value) => {
    if (value === undefined || value === null || value === "" || value === false) return true;
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === "object") return Object.keys(value).length === 0;
    return false;
  };

  const compactValue = (value) => {
    if (Array.isArray(value)) {
      const compactedArray = value
        .map((item) => compactValue(item))
        .filter((item) => !isCompactEmpty(item));
      return compactedArray.length ? compactedArray : undefined;
    }

    if (value && typeof value === "object") {
      const compactedObject = Object.fromEntries(
        Object.entries(value)
          .map(([key, item]) => [key, compactValue(item)])
          .filter(([, item]) => !isCompactEmpty(item))
      );
      return Object.keys(compactedObject).length ? compactedObject : undefined;
    }

    return isCompactEmpty(value) ? undefined : value;
  };

  const compactAgainstDefaults = (value, defaults) => {
    if (Array.isArray(value)) return value.length ? value.map((item) => compactValue(item)).filter((item) => !isCompactEmpty(item)) : undefined;

    if (value && typeof value === "object") {
      const compactedObject = {};
      Object.entries(value).forEach(([key, item]) => {
        const compacted = key in defaults ? compactAgainstDefaults(item, defaults[key]) : compactValue(item);
        if (!isCompactEmpty(compacted)) compactedObject[key] = compacted;
      });
      return Object.keys(compactedObject).length ? compactedObject : undefined;
    }

    if (value === defaults || isCompactEmpty(value)) return undefined;
    return value;
  };

  const compactPatient = (patient) => {
    const patientDefaults = {
      nome: "",
      cognome: "",
      dataNascita: "",
      pseudonimo: "",
      email: "",
      telefono: "",
      codiceFiscale: "",
      indirizzo: "",
      trattamento: "studio_caso",
      dataInizioTrattamento: "",
      preventivo: "",
      dataFineTrattamentoAttivo: "",
      dataUltimoControlloContenzione: "",
      noteTrattamento: "",
      prossimoAppuntamento: "",
      studioCasoChecklist: defaultCaseChecklist,
      esclusoRecall: false,
      diagnosi: defaultDiagnosis,
      igiene: 5,
      compliance: 5,
      arcoSupIndex: 0,
      arcoInfIndex: 0,
      alignerCorrente: 1,
      alignerTotali: 20,
      prescrizioni: [],
      photoSessions: [],
      diario: []
    };

    return {
      id: patient.id,
      studioId: patient.studioId,
      ...(compactAgainstDefaults(patient, patientDefaults) || {})
    };
  };

  const getDatabaseExportText = () => {
    const data = {
      version: 3,
      compact: true,
      exportedAt: new Date().toISOString(),
      studios: studios.map((studio) => compactValue(studio) || studio),
      laboratories: laboratories.map((laboratory) => compactValue(laboratory) || laboratory),
      patients: patients.map(compactPatient),
      selectedId,
      ...(JSON.stringify(wireSequence) !== JSON.stringify(defaultWireSequence) ? { wireSequence } : {}),
      ...(JSON.stringify(lingualWireSequence) !== JSON.stringify(defaultLingualWireSequence) ? { lingualWireSequence } : {}),
      agendaItems: agendaItems.map((item) => compactValue(item) || item),
      materialOrders: materialOrders.map((item) => compactValue(item) || item)
    };
    return JSON.stringify(data);
  };

  const downloadDatabase = (text) => {
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `ortho-patients-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const saveDatabaseWithDesktop = async (text) => {
    if (!window.orthoDesktop?.saveBackup) return false;
    const suggestedName = `ortho-patients-backup-${new Date().toISOString().slice(0, 10)}.json`;
    const result = await window.orthoDesktop.saveBackup({ text, suggestedName });
    if (result?.canceled) return true;
    if (!result?.ok) throw new Error("Salvataggio desktop non riuscito");
    alert(`Database salvato in ${result.filePath || suggestedName}.`);
    return true;
  };

  const getExportTextForSave = async () => {
    const text = getDatabaseExportText();
    if (!encryptBackups) return text;
    if (!sessionPassword) {
      alert("Sblocca di nuovo la app prima di salvare un backup cifrato.");
      return null;
    }
    return encryptBackupText(text, sessionPassword);
  };

  const parseBackupText = async (text) => {
    let data;
    try {
      data = parseBackupJsonText(text);
    } catch {
      throw new Error("Il file non sembra un backup JSON valido.");
    }
    if (!data?.encrypted) return data;
    if (!data.salt || !data.iv || !data.data) {
      throw new Error("Backup cifrato incompleto");
    }
    const candidatePasswords = Array.from(new Set([importPassword.trim(), sessionPassword].filter(Boolean)));
    for (const candidatePassword of candidatePasswords) {
      try {
        return await decryptBackupData(data, candidatePassword);
      } catch {
        // Se una password non coincide, proviamo la successiva.
      }
    }
    const password = window.prompt("Backup cifrato: inserisci la password del backup.");
    if (!password) {
      throw new Error("Backup cifrato: inserisci la password nel campo Password backup e riprova.");
    }
    try {
      return await decryptBackupData(data, password);
    } catch {
      throw new Error("Password backup non corretta oppure backup cifrato danneggiato. Se hai cambiato la password dell'app, prova la password vecchia.");
    }
  };

  const chooseDatabaseSaveFile = async () => {
    if (!window.showSaveFilePicker) {
      alert("Questo browser non permette di memorizzare una destinazione fissa. Il pulsante Salva continuerà a scaricare il JSON.");
      return;
    }

    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: "ortho-patients-backup.json",
        types: [{
          description: "Backup Ortho Patients",
          accept: { "application/json": [".json"] }
        }]
      });
      await storeSetting("databaseFileHandle", handle);
      setSaveFileHandle(handle);
      setSaveFileName(handle.name || "ortho-patients-backup.json");
      alert("Destinazione di salvataggio impostata.");
    } catch (error) {
      if (error?.name !== "AbortError") {
        alert("Non è stato possibile memorizzare la destinazione scelta.");
      }
    }
  };

  const exportDatabase = async () => {
    const text = await getExportTextForSave();
    if (!text) return;
    try {
      if (await saveDatabaseWithDesktop(text)) return;
    } catch {
      alert("Non riesco a salvare il file dalla app standalone. Provo con il download del browser.");
    }

    if (!saveFileHandle) {
      downloadDatabase(text);
      return;
    }

    try {
      const permission = await saveFileHandle.queryPermission({ mode: "readwrite" });
      const granted = permission === "granted"
        || await saveFileHandle.requestPermission({ mode: "readwrite" }) === "granted";
      if (!granted) {
        alert("Permesso di scrittura non concesso. Il backup verrà scaricato normalmente.");
        downloadDatabase(text);
        return;
      }

      const writable = await saveFileHandle.createWritable();
      await writable.truncate(0);
      await writable.write(text);
      await writable.close();
      alert(`Database salvato in ${saveFileName || saveFileHandle.name}.`);
    } catch {
      alert("Non riesco a scrivere nel file scelto. Il backup verrà scaricato normalmente.");
      downloadDatabase(text);
    }
  };

  const applyImportedDatabase = (data, successMessage = "Database importato correttamente.") => {
    if (!Array.isArray(data.studios) || !Array.isArray(data.patients)) {
      alert("File non valido: mancano studi o pazienti.");
      return false;
    }

    const importedStudios = data.studios.length ? data.studios : defaultStudios;
    const importedLaboratories = Array.isArray(data.laboratories) && data.laboratories.length ? data.laboratories : defaultLaboratories;
    setStudios(importedStudios);
    setLaboratories(importedLaboratories);
    setPatients(data.patients.map((patient) => normalizePatient(patient, importedStudios)));
    setSelectedId(data.selectedId || data.patients?.[0]?.id || initialPatients[0].id);
    setWireSequence(Array.isArray(data.wireSequence) ? data.wireSequence : defaultWireSequence);
    setLingualWireSequence(Array.isArray(data.lingualWireSequence) ? data.lingualWireSequence : defaultLingualWireSequence);
    setAgendaItems(Array.isArray(data.agendaItems) ? data.agendaItems : []);
    setMaterialOrders(Array.isArray(data.materialOrders) ? data.materialOrders : []);
    setMaterialDraft((current) => ({
      ...current,
      studioId: importedStudios[0]?.id || defaultStudios[0].id,
      supplierId: importedLaboratories[0]?.id || defaultLaboratories[0].id,
      patientId: ""
    }));
    setImportText("");
    setImportPassword("");
    alert(successMessage);
    return true;
  };

  const importDatabase = async () => {
    try {
      const data = await parseBackupText(importText);
      applyImportedDatabase(data);
    } catch (error) {
      alert(error?.message || "Backup non leggibile o password non corretta.");
    }
  };

  const mergeDatabase = async () => {
    try {
      const data = await parseBackupText(importText);
      if (!Array.isArray(data.patients)) {
        alert("File non valido: mancano i pazienti.");
        return;
      }

      const incomingStudios = Array.isArray(data.studios) ? data.studios : [];
      const incomingLaboratories = Array.isArray(data.laboratories) ? data.laboratories : [];
      const incomingAgendaItems = Array.isArray(data.agendaItems) ? data.agendaItems : [];
      const incomingMaterialOrders = Array.isArray(data.materialOrders) ? data.materialOrders : [];
      const mergedStudios = mergeCollectionById(studios, incomingStudios);
      const mergedLaboratories = mergeCollectionById(laboratories, incomingLaboratories);
      const compactBackup = Boolean(data.compact);

      setStudios(mergedStudios);
      setLaboratories(mergedLaboratories);

      setPatients((currentPatients) => {
        const byId = new Map(currentPatients.map((patient) => [patient.id, patient]));
        data.patients.forEach((patient) => {
          if (!patient?.id) return;
          byId.set(patient.id, mergePatientForImport(byId.get(patient.id), patient, mergedStudios, compactBackup));
        });
        return Array.from(byId.values());
      });

      setAgendaItems((currentItems) => {
        return mergeCollectionById(currentItems, incomingAgendaItems)
          .sort((a, b) => `${a.data || ""} ${a.ora || ""}`.localeCompare(`${b.data || ""} ${b.ora || ""}`));
      });
      setMaterialOrders((currentItems) => mergeCollectionById(currentItems, incomingMaterialOrders));

      if (Array.isArray(data.wireSequence) && data.wireSequence.length) setWireSequence(data.wireSequence);
      if (Array.isArray(data.lingualWireSequence) && data.lingualWireSequence.length) setLingualWireSequence(data.lingualWireSequence);

      setImportText("");
      setImportPassword("");
      alert("Database unito correttamente. I pazienti con stesso ID sono stati aggiornati.");
    } catch (error) {
      alert(error?.message || "Backup non leggibile o password non corretta.");
    }
  };

  const importDatabaseFromFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = String(event.target.result || "");
      try {
        const data = await parseBackupText(text);
        applyImportedDatabase(data, "Database caricato e sostituito correttamente.");
      } catch (error) {
        setImportText(text);
        alert(`${error?.message || "Backup non leggibile o password non corretta."} Ho caricato il testo nel riquadro per controllarlo manualmente.`);
      }
    };
    reader.readAsText(file);
  };

  const parseIcsDate = (value) => {
    if (!value) return { data: "", ora: "" };
    const clean = String(value).replace(/Z$/, "");
    const datePart = clean.slice(0, 8);
    const timePart = clean.includes("T") ? clean.split("T")[1]?.slice(0, 4) : "";
    const data = `${datePart.slice(0, 4)}-${datePart.slice(4, 6)}-${datePart.slice(6, 8)}`;
    const ora = timePart ? `${timePart.slice(0, 2)}:${timePart.slice(2, 4)}` : "09:00";
    return { data, ora };
  };

  const unfoldIcs = (text) => {
    const CR = String.fromCharCode(13);
    const LF = String.fromCharCode(10);
    const TAB = String.fromCharCode(9);
    const normalized = String(text).split(CR + LF).join(LF).split(CR).join(LF);
    const lines = normalized.split(LF);
    const unfolded = [];

    lines.forEach((line) => {
      if ((line.startsWith(" ") || line.startsWith(TAB)) && unfolded.length > 0) {
        unfolded[unfolded.length - 1] += line.slice(1);
      } else {
        unfolded.push(line);
      }
    });

    return unfolded;
  };

  const parseIcsText = (text) => {
    const lines = unfoldIcs(text);
    const events = [];
    let current = null;

    lines.forEach((line) => {
      if (line === "BEGIN:VEVENT") {
        current = {};
        return;
      }
      if (line === "END:VEVENT") {
        if (current) {
          const start = parseIcsDate(current.dtstart);
          events.push({
            id: `ics-${Date.now()}-${events.length}`,
            data: start.data,
            ora: start.ora,
            titolo: current.summary || "Appuntamento importato",
            descrizione: current.description || "",
            luogo: current.location || ""
          });
        }
        current = null;
        return;
      }
      if (!current) return;
      const separatorIndex = line.indexOf(":");
      if (separatorIndex < 0) return;
      const rawKey = line.slice(0, separatorIndex);
      const value = line.slice(separatorIndex + 1).replace(/\n/g, " ").replace(/,/g, ",");
      const key = rawKey.split(";")[0].toUpperCase();
      if (key === "DTSTART") current.dtstart = value;
      if (key === "SUMMARY") current.summary = value;
      if (key === "DESCRIPTION") current.description = value;
      if (key === "LOCATION") current.location = value;
    });

    return events.filter((event) => event.data);
  };

  const importIcsFromFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const parsed = parseIcsText(String(event.target.result || ""));
      setIcsEvents(parsed);
      const initialAssignments = {};
      parsed.forEach((event) => {
        const text = `${event.titolo} ${event.descrizione}`.toLowerCase();
        const found = patients.find((p) => text.includes(`${p.cognome} ${p.nome}`.toLowerCase()) || text.includes(`${p.nome} ${p.cognome}`.toLowerCase()) || (p.pseudonimo && text.includes(p.pseudonimo.toLowerCase())));
        if (found) initialAssignments[event.id] = found.id;
      });
      setIcsAssignments(initialAssignments);
    };
    reader.readAsText(file);
  };

  const acceptIcsEvent = (event) => {
    const patientId = icsAssignments[event.id];
    if (!patientId) return;
    const patient = patients.find((p) => p.id === patientId);
    setAgendaItems((current) => [
      ...current,
      {
        id: `a-ics-${Date.now()}-${event.id}`,
        data: event.data,
        ora: event.ora,
        patientId,
        studioId: patient?.studioId || studios[0]?.id || "studio-1",
        motivo: event.titolo || "Appuntamento importato da ICS"
      }
    ].sort((a, b) => `${a.data} ${a.ora}`.localeCompare(`${b.data} ${b.ora}`)));
    setIcsEvents((current) => current.filter((item) => item.id !== event.id));
  };

  const discardIcsEvent = (eventId) => {
    setIcsEvents((current) => current.filter((event) => event.id !== eventId));
  };

  const expectedAlignerInfo = getExpectedAlignerInfo(selectedPatient);
  const latestAlignerDelivery = getLatestAlignerDelivery(selectedPatient);

  const lockApp = () => {
    if (!authConfig) return;
    setIsUnlocked(false);
    setSessionPassword("");
    setAuthDraft((current) => ({ ...current, password: "" }));
    setAuthMessage("App bloccata.");
  };

  const setupPassword = async () => {
    if (authDraft.password.length < 8) {
      setAuthMessage("Usa almeno 8 caratteri.");
      return;
    }
    if (authDraft.password !== authDraft.confirmPassword) {
      setAuthMessage("Le password non coincidono.");
      return;
    }
    const hashed = await hashPassword(authDraft.password);
    const nextAuth = { ...hashed, createdAt: new Date().toISOString() };
    try { setLocalSetting("orthoPatientsAuth", JSON.stringify(nextAuth)); }
    catch { setAuthMessage("Il browser non permette di salvare la password. Controlla i permessi dei dati del sito."); return; }
    setAuthConfig(nextAuth);
    setIsUnlocked(true);
    setSessionPassword(authDraft.password);
    setAuthDraft({ password: "", confirmPassword: "", currentPassword: "", newPassword: "", confirmNewPassword: "" });
    setAuthMessage("");
  };

  const unlockApp = async () => {
    if (!authConfig) {
      setIsUnlocked(true);
      return;
    }
    const hashed = await hashPassword(authDraft.password, authConfig.salt);
    if (hashed.hash !== authConfig.hash) {
      setAuthMessage("Password non corretta.");
      return;
    }
    setIsUnlocked(true);
    setSessionPassword(authDraft.password);
    setAuthDraft((current) => ({ ...current, password: "" }));
    setAuthMessage("");
  };

  const changePassword = async () => {
    if (!authConfig) return;
    const currentHash = await hashPassword(authDraft.currentPassword, authConfig.salt);
    if (currentHash.hash !== authConfig.hash) {
      setAuthMessage("Password attuale non corretta.");
      return;
    }
    if (authDraft.newPassword.length < 8) {
      setAuthMessage("La nuova password deve avere almeno 8 caratteri.");
      return;
    }
    if (authDraft.newPassword !== authDraft.confirmNewPassword) {
      setAuthMessage("Le nuove password non coincidono.");
      return;
    }
    const nextAuth = { ...(await hashPassword(authDraft.newPassword)), createdAt: authConfig.createdAt, updatedAt: new Date().toISOString() };
    try { setLocalSetting("orthoPatientsAuth", JSON.stringify(nextAuth)); }
    catch { setAuthMessage("Il browser non permette di salvare la password. Controlla i permessi dei dati del sito."); return; }
    setAuthConfig(nextAuth);
    setSessionPassword(authDraft.newPassword);
    setAuthDraft({ password: "", confirmPassword: "", currentPassword: "", newPassword: "", confirmNewPassword: "" });
    setAuthMessage("Password aggiornata.");
  };

  if (!demo && (!authConfig || !isUnlocked)) {
    const isSetup = !authConfig;
    return (
      <>
        <style>{css}</style>
        <div className="lockScreen">
          <div className="lockCard">
            <div className="lockMark">OP</div>
            <h1>{isSetup ? "Proteggi Ortho Patients" : "Ortho Patients"}</h1>
            <p>{isSetup ? "Imposta una password locale per aprire la app." : "Inserisci la password per continuare."}</p>

            {isSetup ? (
              <>
                <input
                  className="input"
                  type="password"
                  autoFocus
                  placeholder="Nuova password"
                  value={authDraft.password}
                  onChange={(e) => setAuthDraft({ ...authDraft, password: e.target.value })}
                  onKeyDown={(e) => { if (e.key === "Enter") setupPassword(); }}
                />
                <input
                  className="input"
                  type="password"
                  placeholder="Ripeti password"
                  value={authDraft.confirmPassword}
                  onChange={(e) => setAuthDraft({ ...authDraft, confirmPassword: e.target.value })}
                  onKeyDown={(e) => { if (e.key === "Enter") setupPassword(); }}
                />
                <Button onClick={setupPassword}>Imposta password</Button>
              </>
            ) : (
              <>
                <input
                  className="input"
                  type="password"
                  autoFocus
                  placeholder="Password"
                  value={authDraft.password}
                  onChange={(e) => setAuthDraft({ ...authDraft, password: e.target.value })}
                  onKeyDown={(e) => { if (e.key === "Enter") unlockApp(); }}
                />
                <Button onClick={unlockApp}>Sblocca</Button>
              </>
            )}

            {authMessage && <small className="authMessage">{authMessage}</small>}
            <Button secondary onClick={onExit}>Torna all’inizio</Button>
            <small className="privacyNote">Nota: questa password protegge l’apertura locale della app. I backup JSON vanno comunque conservati in una posizione protetta.</small>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{css}</style>
      <div className="webSessionBar"><p>{demo ? "Demo · pazienti fittizi. Le modifiche durano fino all’uscita o al ricaricamento." : "Archivio locale · dati salvati in questo browser. Esporta regolarmente un backup."}</p><button type="button" onClick={onExit}>{demo ? "Esci dalla demo" : "Torna all’inizio"}</button></div>
      <div className="app">
        <div className="header">
          <div>
            <h1>Ortho Patients <small style={{ fontSize: "0.45em", fontWeight: 500 }}>Web 0.4</small></h1>
            <p>Database ortodontico locale: pazienti, diario, foto, agenda e trattamenti.</p>
            {storageWarning && <div className="storageWarning">{storageWarning}</div>}
          </div>
          <div className="topDatabaseActions">
            <button className="topActionButton" type="button" onClick={exportDatabase}>Salva</button>
            <label className="topActionButton">
              Carica
              <input
                type="file"
                accept="application/json"
                onChange={(e) => {
                  importDatabaseFromFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
            {!demo && <button className="topActionButton" type="button" onClick={lockApp}>Blocca</button>}
            <Button onClick={addPatient}>+ Nuovo paziente</Button>
          </div>
        </div>

        <div className="layout fullWidth">
          <main>
            {patients.length === 0 && <Card><h2>Il tuo archivio è pronto</h2><p>Aggiungi il primo paziente oppure carica un backup con il pulsante Carica.</p><Button onClick={addPatient}>Aggiungi il primo paziente</Button></Card>}
            <div className="tabs">
              {["agenda", "diagnosi", "trattamento", "diario", "foto", "preferenze"].map((tab) => (
                <button key={tab} className={activeTab === tab ? "tab activeTab" : "tab"} onClick={() => setActiveTab(tab)} type="button">
                  {tab}
                </button>
              ))}
            </div>

            <div className="patientPickerBar">
              <div className="selectedPatientSummary">
                <span>Paziente selezionato</span>
                <strong>{selectedPatient?.cognome || "Cognome"} {selectedPatient?.nome || "Nome"}</strong>
                <small>{selectedPatient?.pseudonimo ? `${selectedPatient.pseudonimo} · ` : ""}{selectedStudio?.nome || "Studio non indicato"}</small>
              </div>
              <Button small secondary onClick={() => setShowPatientSheet(true)}>Scheda</Button>
              <input
                className="input"
                placeholder="Cerca e cambia paziente"
                value={patientSearch}
                onChange={(e) => setPatientSearch(e.target.value)}
              />
              <select className="input" value={filterStudio} onChange={(e) => setFilterStudio(e.target.value)}>
                <option value="all">Tutti gli studi</option>
                {studios.map((s) => <option key={s.id} value={s.id}>{s.nome}</option>)}
              </select>
              {patientSearch.trim() && (
                <div className="globalPatientMatches">
                  {filteredPatients.length === 0 ? (
                    <div className="emptyState compactEmpty">Nessun paziente trovato.</div>
                  ) : (
                    filteredPatients.slice(0, 8).map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          setSelectedId(p.id);
                          setNewAgendaItem((current) => ({ ...current, patientId: p.id, motivo: appointmentReason(p) }));
                          setPatientSearch("");
                        }}
                        className={`patientButton ${selectedId === p.id ? "active" : ""}`}
                        type="button"
                      >
                        <strong>{p.cognome || "Cognome"} {p.nome || "Nome"}</strong>
                        <span>{ageFromDate(p.dataNascita)} anni{p.pseudonimo ? ` · ${p.pseudonimo}` : ""}</span>
                        <small>{studios.find((studio) => studio.id === p.studioId)?.nome || "Studio non indicato"}</small>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {showPatientSheet && selectedPatient && (
              <div className="sheetOverlay" role="dialog" aria-modal="true" aria-label="Scheda paziente">
                <div className="sheetPanel">
                <div className="sectionHeader">
                  <div>
                    <h2>Scheda paziente</h2>
                    <p>
                      Studio: {selectedStudio?.nome || "—"} · Ultima foto: {getLastPhotoDate(selectedPatient)}
                      {getNextAppointment(selectedPatient.id) && ` · Prossimo appuntamento: ${formatDateIT(getNextAppointment(selectedPatient.id).data)} ore ${getNextAppointment(selectedPatient.id).ora}`}
                    </p>
                  </div>
                  <div className="headerActions">
                    <Badge>{treatmentLabel(selectedPatient.trattamento)}</Badge>
                    <Button small secondary onClick={() => setShowPatientSheet(false)}>Chiudi</Button>
                    <Button small secondary onClick={() => deletePatient(selectedPatient.id)}>Elimina paziente</Button>
                  </div>
                </div>

                <div className="grid2">
                  <input className="input" placeholder="Nome" value={selectedPatient.nome} onChange={(e) => updatePatient({ nome: e.target.value })} />
                  <input className="input" placeholder="Cognome" value={selectedPatient.cognome} onChange={(e) => updatePatient({ cognome: e.target.value })} />
                  <input className="input" type="date" value={selectedPatient.dataNascita} onChange={(e) => updatePatient({ dataNascita: e.target.value })} />
                  <input className="input" placeholder="Pseudonimo" value={selectedPatient.pseudonimo} onChange={(e) => updatePatient({ pseudonimo: e.target.value })} />
                  <input className="input" placeholder="E-mail" value={selectedPatient.email} onChange={(e) => updatePatient({ email: e.target.value })} />
                  <input className="input" placeholder="Telefono" value={selectedPatient.telefono} onChange={(e) => updatePatient({ telefono: e.target.value })} />
                  <input className="input" placeholder="Codice fiscale per fatturazione" value={selectedPatient.codiceFiscale || ""} onChange={(e) => updatePatient({ codiceFiscale: e.target.value.toUpperCase() })} />
                  <input className="input" placeholder="Indirizzo per fatturazione" value={selectedPatient.indirizzo || ""} onChange={(e) => updatePatient({ indirizzo: e.target.value })} />
                  <select className="input" value={selectedPatient.studioId} onChange={(e) => updatePatient({ studioId: e.target.value })}>
                    {studios.map((s) => <option key={s.id} value={s.id}>{s.nome}</option>)}
                  </select>
                  <select className="input" value={selectedPatient.trattamento} onChange={(e) => updatePatient({ trattamento: e.target.value })}>
                    <option value="studio_caso">Studio caso</option>
                    <option value="fissa">Fissa tradizionale</option>
                    <option value="fissa_estetica">Fissa estetica</option>
                    <option value="linguale">Linguale</option>
                    <option value="allineatori">Allineatori</option>
                    <option value="intercettiva">Intercettiva</option>
                    <option value="contenzione">Contenzione</option>
                    <option value="perso">Perso</option>
                  </select>
                </div>

                <div className="grid2 spaced">
                  <ScoreSlider label="Igiene orale" value={selectedPatient.igiene} type="igiene" onChange={(v) => updatePatient({ igiene: v })} />
                  <ScoreSlider label="Compliance" value={selectedPatient.compliance} type="compliance" onChange={(v) => updatePatient({ compliance: v })} />
                </div>
                </div>
              </div>
            )}

            {activeTab === "diagnosi" && selectedPatient && (
              <Card>
                <div className="sectionHeader">
                  <div>
                    <h2>Diagnosi</h2>
                    <p>{selectedPatient.cognome || "Cognome"} {selectedPatient.nome || "Nome"}</p>
                  </div>
                  {selectedPatient.pseudonimo && <Badge>{selectedPatient.pseudonimo}</Badge>}
                </div>

                <div className="grid3">
                  <label className="diagnosisField">
                    <span>Classe dentale</span>
                    <select className="input" value={selectedPatient.diagnosi?.classeDentale || "I"} onChange={(e) => updateDiagnosis({ classeDentale: e.target.value })}>
                      <option value="I">I</option>
                      <option value="II">II</option>
                      <option value="III">III</option>
                    </select>
                  </label>

                  <label className="diagnosisField">
                    <span>Classe scheletrica</span>
                    <select className="input" value={selectedPatient.diagnosi?.classeScheletrica || "I"} onChange={(e) => updateDiagnosis({ classeScheletrica: e.target.value })}>
                      <option value="I">I</option>
                      <option value="II">II</option>
                      <option value="III">III</option>
                    </select>
                  </label>

                  <label className="diagnosisField">
                    <span>Divergenza</span>
                    <select
                      className="input"
                      value={{
                        normale: "normodivergente",
                        ipodivergenza: "ipodivergente",
                        iperdivergenza: "iperdivergente"
                      }[selectedPatient.diagnosi?.divergenza] || selectedPatient.diagnosi?.divergenza || "normodivergente"}
                      onChange={(e) => updateDiagnosis({ divergenza: e.target.value })}
                    >
                      <option value="ipodivergente">Ipodivergente</option>
                      <option value="normodivergente">Normodivergente</option>
                      <option value="iperdivergente">Iperdivergente</option>
                    </select>
                  </label>
                </div>

                <div className="diagnosisTextGrid">
                  <label className="diagnosisField">
                    <span>Fase di crescita</span>
                    <input className="input" value={selectedPatient.diagnosi?.faseCrescita || ""} onChange={(e) => updateDiagnosis({ faseCrescita: e.target.value })} />
                  </label>
                  <label className="diagnosisField">
                    <span>CC</span>
                    <input className="input" value={selectedPatient.diagnosi?.cc || ""} onChange={(e) => updateDiagnosis({ cc: e.target.value })} />
                  </label>
                  <label className="diagnosisField">
                    <span>Agenesie / sovrannumerari</span>
                    <input className="input" value={selectedPatient.diagnosi?.agenesieSovrannumerari || ""} onChange={(e) => updateDiagnosis({ agenesieSovrannumerari: e.target.value })} />
                  </label>
                  <label className="diagnosisField">
                    <span>Discrepanza trasversale</span>
                    <select className="input" value={selectedPatient.diagnosi?.discrepanzaTrasversale || "no"} onChange={(e) => updateDiagnosis({ discrepanzaTrasversale: e.target.value })}>
                      <option value="no">No</option>
                      <option value="si">Sì</option>
                    </select>
                  </label>
                  <label className="diagnosisField">
                    <span>Nota libera</span>
                    <textarea className="textarea" value={selectedPatient.diagnosi?.notaLibera || ""} onChange={(e) => updateDiagnosis({ notaLibera: e.target.value })} />
                  </label>
                </div>

                <div className="therapyPlanBox">
                  <h3>Piano terapeutico</h3>
                  <label className="diagnosisField">
                    <span>Durata prevista</span>
                    <input className="input" value={selectedPatient.diagnosi?.pianoTerapeutico?.durataPrevista || ""} onChange={(e) => updateTreatmentPlan({ durataPrevista: e.target.value })} />
                  </label>
                  <label className="diagnosisField">
                    <span>Obiettivi terapeutici</span>
                    <textarea className="textarea" value={selectedPatient.diagnosi?.pianoTerapeutico?.obiettivi || ""} onChange={(e) => updateTreatmentPlan({ obiettivi: e.target.value })} />
                  </label>
                </div>

                <div className="therapyPlanBox">
                  <div className="sectionHeader compact">
                    <h3>Preventivo</h3>
                    <Badge>{formatCurrencyIT(selectedPatient.preventivo || 0)}</Badge>
                  </div>
                  <div className="quoteGrid">
                    <div className="quoteAmountColumn">
                      <label className="diagnosisField">
                        <span>Importo preventivo</span>
                        <input
                          className="input"
                          type="number"
                          value={selectedPatient.preventivo || ""}
                          onChange={(e) => updatePatient({ preventivo: e.target.value })}
                          placeholder="€"
                        />
                      </label>

                      <details className="quoteEstimateDetails">
                        <summary title="Calcola un preventivo possibile" aria-label="Calcola un preventivo possibile">?</summary>
                        <div className="quoteEstimatePanel">
                          <div className="quoteEstimateGrid">
                            <label className="diagnosisField">
                              <span>Spese totali</span>
                              <input
                                className="input"
                                type="number"
                                min="0"
                                value={quoteEstimateDraft.spese}
                                onChange={(e) => setQuoteEstimateDraft({ ...quoteEstimateDraft, spese: e.target.value })}
                                placeholder="€"
                              />
                            </label>
                            <label className="diagnosisField">
                              <span>Percentuale ortodontista</span>
                              <input
                                className="input"
                                type="number"
                                min="0"
                                max="100"
                                value={quoteEstimateDraft.percentualeOrtodontista}
                                onChange={(e) => setQuoteEstimateDraft({ ...quoteEstimateDraft, percentualeOrtodontista: e.target.value })}
                                placeholder="%"
                              />
                            </label>
                            <label className="diagnosisField">
                              <span>Spese a carico dello studio</span>
                              <input
                                className="input"
                                type="number"
                                min="0"
                                max="100"
                                value={quoteEstimateDraft.percentualeSpeseStudio}
                                onChange={(e) => setQuoteEstimateDraft({ ...quoteEstimateDraft, percentualeSpeseStudio: e.target.value })}
                                placeholder="%"
                              />
                            </label>
                            <label className="diagnosisField">
                              <span>Durata trattamento</span>
                              <input
                                className="input"
                                type="number"
                                min="1"
                                value={quoteEstimateDraft.durataMesi}
                                onChange={(e) => setQuoteEstimateDraft({ ...quoteEstimateDraft, durataMesi: e.target.value })}
                                placeholder="mesi"
                              />
                            </label>
                            <label className="diagnosisField fullSpan">
                              <span>Ricavo netto mensile ortodontista</span>
                              <input
                                className="input"
                                type="number"
                                min="0"
                                value={quoteEstimateDraft.ricavoMensile}
                                onChange={(e) => setQuoteEstimateDraft({ ...quoteEstimateDraft, ricavoMensile: e.target.value })}
                                placeholder="€ al mese"
                              />
                            </label>
                          </div>

                          {(() => {
                            const estimate = getQuoteEstimate();
                            if (estimate.incomplete) return <small className="quoteEstimateEmpty">Inserisci i cinque valori per ottenere la stima.</small>;
                            if (!estimate.valid) return <div className="quoteEstimateWarning">{estimate.message}</div>;
                            return (
                              <div className="quoteEstimateResult">
                                <span>Preventivo finale stimato</span>
                                <strong>{formatCurrencyIT(estimate.finalEstimate)}</strong>
                                {estimate.durationMonths > 0 && <small>Media mensile: {formatCurrencyIT(estimate.monthly)}</small>}
                                <div className="quoteEstimateBreakdown">
                                  <small>Pareggio: {formatCurrencyIT(estimate.estimate)}</small>
                                  <small>Ricavo ortodontista richiesto: {formatCurrencyIT(estimate.monthlyRevenue)} × {estimate.durationMonths} mesi = {formatCurrencyIT(estimate.desiredOrthodontistRevenue)}</small>
                                  <small>Ortodontista: quota {formatCurrencyIT(estimate.orthodontistAmount)} · spese {formatCurrencyIT(estimate.orthodontistExpenses)} · ricavo netto {formatCurrencyIT(estimate.orthodontistNetRevenue)}</small>
                                  <small>Studio: quota {formatCurrencyIT(estimate.studioAmount)} · spese {formatCurrencyIT(estimate.studioExpenses)} · ricavo netto {formatCurrencyIT(estimate.studioNetRevenue)}</small>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      </details>
                    </div>

                    <details className="paymentDetails">
                      <summary>Calcola rate</summary>
                      <div className="paymentCalculator">
                        <div className="grid4">
                          <label className="diagnosisField">
                            <span>Rata iniziale</span>
                            <input
                              className="input"
                              type="number"
                              value={paymentDraft.rataIniziale}
                              onChange={(e) => setPaymentDraft({ ...paymentDraft, rataIniziale: e.target.value })}
                              placeholder="€"
                            />
                          </label>
                          <label className="diagnosisField">
                            <span>Numero rate totali</span>
                            <input
                              className="input"
                              type="number"
                              min="1"
                              value={paymentDraft.numeroRate}
                              onChange={(e) => setPaymentDraft({ ...paymentDraft, numeroRate: e.target.value })}
                            />
                          </label>
                          <label className="diagnosisField">
                            <span>Durata trattamento (mesi)</span>
                            <input
                              className="input"
                              type="number"
                              min="1"
                              value={paymentDraft.durataTrattamento}
                              onChange={(e) => setPaymentDraft({ ...paymentDraft, durataTrattamento: e.target.value })}
                            />
                          </label>
                          <label className="diagnosisField">
                            <span>Data iniziale rate</span>
                            <input
                              className="input"
                              type="date"
                              value={paymentDraft.dataInizio}
                              onChange={(e) => setPaymentDraft({ ...paymentDraft, dataInizio: e.target.value })}
                            />
                          </label>
                          <label className="diagnosisField">
                            <span>Prezzo scontato del (%)</span>
                            <input
                              className="input"
                              type="number"
                              min="0"
                              max="100"
                              value={paymentDraft.scontoPercentuale}
                              onChange={(e) => setPaymentDraft({ ...paymentDraft, scontoPercentuale: e.target.value })}
                              placeholder="%"
                            />
                          </label>
                        </div>

                        <textarea
                          className="textarea tall paymentOutput"
                          value={getPaymentSummary()}
                          readOnly
                        />
                        <div className="diagnosisExportActions">
                          <Button secondary onClick={copyPaymentSummary}>Copia riepilogo</Button>
                        </div>
                      </div>
                    </details>
                  </div>
                </div>

                <div className="therapyPlanBox">
                  <h3>Export diagnosi</h3>
                  <div className="diagnosisExportActions">
                    <Button onClick={buildDiagnosisExport}>Genera testo diagnosi</Button>
                    <Button secondary onClick={copyDiagnosisExport} disabled={!diagnosisExportText}>Copia testo</Button>
                  </div>
                  {diagnosisExportText && (
                    <textarea
                      className="textarea tall"
                      value={diagnosisExportText}
                      onChange={(e) => setDiagnosisExportText(e.target.value)}
                    />
                  )}
                </div>
              </Card>
            )}

            {activeTab === "diario" && selectedPatient && (
              <>
                <div className="diaryPatientHeader">
                  <div>
                    <h2>{selectedPatient.cognome || "Cognome"} {selectedPatient.nome || "Nome"}</h2>
                    <p>{selectedPatient.pseudonimo ? `${selectedPatient.pseudonimo} · ` : ""}{selectedStudio?.nome || "Studio non indicato"}</p>
                  </div>
                  {getPatientAlignerCoverage(selectedPatient) && <Badge>Coperto fino a {formatDateIT(getPatientAlignerCoverage(selectedPatient))}</Badge>}
                </div>

                <div className="diaryGrid">
                  <Card>
                    <h2>{autoDiaryEntryId && (selectedPatient.diario || []).some((entry) => entry.id === autoDiaryEntryId) ? "Modifica appuntamento" : "Nuovo appuntamento"}</h2>
                    <label className="diaryDateField">
                      <span>Data appuntamento</span>
                      <input className="input" type="date" value={draftDiary.data} onChange={(e) => updateDiaryDraft({ data: e.target.value })} />
                    </label>

                    <select className="input" value={draftDiary.tipo} onChange={(e) => updateDiaryDraft({ tipo: e.target.value })}>
                      <option>Controllo ortodontico</option>
                      <option>Bonding</option>
                      <option>Consegna allineatori</option>
                      <option>Controllo elastici</option>
                      <option>Urgenza</option>
                      <option>Debonding</option>
                      <option>Contenzione</option>
                      <option>Scansione</option>
                    </select>

                    <textarea className="textarea" placeholder="Azione clinica eseguita" value={draftDiary.azione} onChange={(e) => updateDiaryDraft({ azione: e.target.value })} />

                    {isFixedApplianceTreatment(selectedPatient.trattamento) && (
                      <div className="grid2">
                        <label className="diagnosisField">
                          <span>Arco superiore inserito</span>
                          <select className="input" value={draftDiary.arcoSup || getLastDiaryWire(selectedPatient, "sup")} onChange={(e) => updateDiaryDraft({ arcoSup: e.target.value })}>
                            {activeWireSequence.map((wire) => <option key={`sup-${wire}`} value={wire}>{wire}</option>)}
                          </select>
                        </label>
                        <label className="diagnosisField">
                          <span>Arco inferiore inserito</span>
                          <select className="input" value={draftDiary.arcoInf || getLastDiaryWire(selectedPatient, "inf")} onChange={(e) => updateDiaryDraft({ arcoInf: e.target.value })}>
                            {activeWireSequence.map((wire) => <option key={`inf-${wire}`} value={wire}>{wire}</option>)}
                          </select>
                        </label>
                        <label className="diagnosisField fullSpan">
                          <span>Nota archi</span>
                          <input
                            className="input"
                            value={draftDiary.arcoNote}
                            onChange={(e) => updateDiaryDraft({ arcoNote: e.target.value })}
                            placeholder="Riga libera modificabile sul momento"
                          />
                        </label>
                      </div>
                    )}

                    {selectedPatient.trattamento === "allineatori" && (
                      <div className="alignerDeliveryBox">
                        {draftDiary.tipo !== "Consegna allineatori" && (
                          <label className="diagnosisField">
                            <span>Aligner consegnato / controllato</span>
                            <input className="input" type="number" value={draftDiary.aligner} onChange={(e) => updateDiaryDraft({ aligner: e.target.value })} placeholder="Numero aligner singolo" />
                          </label>
                        )}

                        {draftDiary.tipo === "Consegna allineatori" && (
                          <>
                            <div className="grid4">
                              <label className="diagnosisField">
                                <span>Da</span>
                                <input className="input" type="number" value={draftDiary.alignerDelivery.da} onChange={(e) => updateDiaryDeliveryDraft({ da: e.target.value })} />
                              </label>
                              <label className="diagnosisField">
                                <span>A</span>
                                <input className="input" type="number" value={draftDiary.alignerDelivery.a} onChange={(e) => updateDiaryDeliveryDraft({ a: e.target.value })} />
                              </label>
                              <label className="diagnosisField">
                                <span>Ogni</span>
                                <select className="input" value={draftDiary.alignerDelivery.cambioGiorni} onChange={(e) => updateDiaryDeliveryDraft({ cambioGiorni: Number(e.target.value) })}>
                                  <option value={5}>5 giorni</option>
                                  <option value={7}>7 giorni</option>
                                  <option value={10}>10 giorni</option>
                                  <option value={14}>14 giorni</option>
                                </select>
                              </label>
                              <label className="diagnosisField">
                                <span>Inizio</span>
                                <input className="input" type="date" value={draftDiary.alignerDelivery.dataInizio} onChange={(e) => updateDiaryDeliveryDraft({ dataInizio: e.target.value })} />
                              </label>
                            </div>

                            <label className="checkRow">
                              <input
                                type="checkbox"
                                checked={Boolean(draftDiary.alignerDelivery.aligner1Doppio)}
                                onChange={(e) => updateDiaryDeliveryDraft({ aligner1Doppio: e.target.checked })}
                              />
                              <span>2x aligner 1</span>
                            </label>

                            {getAlignerSchedule(draftDiary.alignerDelivery).coveredUntil && (
                              <div className="coverageBox">Paziente coperto con allineatori fino al <strong>{formatDateIT(getAlignerSchedule(draftDiary.alignerDelivery).coveredUntil)}</strong></div>
                            )}

                            {getAlignerSchedule(draftDiary.alignerDelivery).rows.length > 0 && (
                              <details className="alignerScheduleDetails">
                                <summary>Progressione allineatori</summary>
                                <div className="alignerScheduleTable">
                                  {getAlignerSchedule(draftDiary.alignerDelivery).rows.map((row) => (
                                    <div key={row.aligner} className="alignerScheduleRow">
                                      <strong>#{row.aligner}</strong>
                                      <span>{formatDateIT(row.start)}</span>
                                      <span>{formatDateIT(row.end)}</span>
                                    </div>
                                  ))}
                                </div>
                              </details>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    {(selectedPatient.trattamento === "allineatori" || isFixedApplianceTreatment(selectedPatient.trattamento)) && (
                      <div className="collapsibleBox">
                        <button
                          className="collapsibleHeader"
                          type="button"
                          onClick={() => setShowDiaryElastics(!showDiaryElastics)}
                        >
                          <strong>Elastici</strong>
                          <span>{showDiaryElastics ? "▲ chiudi" : "▼ apri"}</span>
                        </button>

                        {showDiaryElastics && (
                          <ElasticDiagram
                            elastici={draftDiary.elastici}
                            setElastici={(elastici) => updateDiaryDraft({ elastici })}
                          />
                        )}
                      </div>
                    )}

                    <label className="checkRow">
                      <input type="checkbox" checked={draftDiary.foto} onChange={(e) => updateDiaryDraft({ foto: e.target.checked })} />
                      <span>Foto eseguita in questo appuntamento</span>
                    </label>

                    <div className="diaryAutosaveRow">
                      <span>{diaryAutosaveStatus || "Il diario si salva automaticamente appena compili il modulo."}</span>
                      <Button secondary onClick={resetDiaryDraft}>Nuovo appuntamento</Button>
                    </div>
                  </Card>

                  <div className="timeline">
                    {(selectedPatient.diario || []).map((d) => {
                      const isOpen = openDiaryEntryId === d.id;
                      const linkedPhotoSessions = (selectedPatient.photoSessions || []).filter((session) => session.diarioEntryId === d.id);
                      return (
                        <Card key={d.id}>
                          <button className={`diaryCompactRow ${isOpen ? "selectedDiaryRow" : ""}`} type="button" onClick={() => selectDiaryEntryForEdit(d)}>
                            <div>
                              <strong>{formatDateIT(d.data)}</strong>
                              <span>{d.tipo}</span>
                            </div>
                            <div className="diaryWireSummary">
                              {d.arcoSup && <Badge>Sup {d.arcoSup}</Badge>}
                              {d.arcoInf && <Badge>Inf {d.arcoInf}</Badge>}
                              {d.aligner && <Badge>Aligner {d.aligner}</Badge>}
                              {d.foto && <Badge>📷</Badge>}
                              {linkedPhotoSessions.length > 0 && <Badge>Set foto</Badge>}
                            </div>
                          </button>

                          {isOpen && (
                            <div className="diaryFullCard">
                              {d.azione && <p className="diaryPreviewText">{d.azione}</p>}
                              <div className="chips">
                                {d.arcoSup && <Badge>Sup {d.arcoSup}</Badge>}
                                {d.arcoInf && <Badge>Inf {d.arcoInf}</Badge>}
                                {d.aligner && <Badge>Aligner {d.aligner}</Badge>}
                                {d.foto && <Badge>📷 Foto</Badge>}
                              </div>

                              {d.alignerDelivery?.schedule?.length > 0 && (
                                <details className="alignerScheduleDetails savedSchedule">
                                  <summary>Progressione allineatori</summary>
                                  <div className="alignerScheduleTable">
                                    {d.alignerDelivery.schedule.map((row) => (
                                      <div key={row.aligner} className="alignerScheduleRow">
                                        <strong>#{row.aligner}</strong>
                                        <span>{formatDateIT(row.start)}</span>
                                        <span>{formatDateIT(row.end)}</span>
                                      </div>
                                    ))}
                                  </div>
                                </details>
                              )}

                              {d.elastici?.length > 0 && <small>Elastici: {d.elastici.map((e) => `${e.tipo} ${e.forza} ${e.elementi.join("-")}`).join(", ")}</small>}

                              {linkedPhotoSessions.map((session) => (
                                <small key={session.id} className="linkedPhotoInfo">Set foto collegato: {formatDateIT(session.data)} · {session.tipo}</small>
                              ))}

                              <div className="diaryEntryActions">
                                <small>Modifica questo appuntamento nel modulo a sinistra.</small>
                                <Button small secondary onClick={() => deleteDiaryEntry(d.id)}>Elimina appuntamento</Button>
                              </div>
                            </div>
                          )}
                        </Card>
                      );
                    })}
                  </div>
                </div>
              </>
            )}

            {activeTab === "foto" && selectedPatient && (
              <Card>
                <div className="sectionHeader">
                  <div>
                    <h2>{photoSearchDate ? "Foto per data" : "Foto paziente"}</h2>
                    <p>
                      {photoSearchDate
                        ? `Stai vedendo tutti i set fotografici del ${formatDateIT(photoSearchDate)}`
                        : `Ultima foto del paziente: ${getLastPhotoDate(selectedPatient)}`}
                    </p>
                  </div>
                  <Badge>{photoSearchDate ? `${photoSearchResults.length} risultati` : `${(selectedPatient.photoSessions || []).length} set`}</Badge>
                </div>

                <div className="photoDateSearchPanel">
                  <div>
                    <span>Ricerca archivio foto</span>
                    <strong>Cerca set fotografici per data</strong>
                    <small>Questa ricerca guarda tutti i pazienti e non cambia il paziente selezionato.</small>
                  </div>
                  <label className="diagnosisField">
                    <span>Data foto</span>
                    <input className="input" type="date" value={photoSearchDate} onChange={(e) => setPhotoSearchDate(e.target.value)} />
                  </label>
                  {photoSearchDate && <Button small secondary onClick={() => setPhotoSearchDate("")}>Reset data</Button>}
                </div>

                <div className="photoUploader">
                  <div className="grid3">
                    <label className="diagnosisField">
                      <span>Data set fotografico</span>
                      <input className="input" type="date" value={photoDraft.data} onChange={(e) => setPhotoDraft({ ...photoDraft, data: e.target.value })} />
                    </label>
                    <label className="diagnosisField">
                      <span>Tipo set</span>
                      <select className="input" value={photoDraft.tipo} onChange={(e) => setPhotoDraft({ ...photoDraft, tipo: e.target.value })}>
                        <option>Foto iniziali</option>
                        <option>Foto controllo</option>
                        <option>Foto finali</option>
                        <option>Urgenza</option>
                        <option>Contenzione</option>
                      </select>
                    </label>
                    <label className="diagnosisField">
                      <span>Appuntamento collegato</span>
                      <select className="input" value={photoDraft.diarioEntryId} onChange={(e) => setPhotoDraft({ ...photoDraft, diarioEntryId: e.target.value })}>
                        <option value="">Nessun collegamento</option>
                        {(selectedPatient.diario || []).map((entry) => <option key={entry.id} value={entry.id}>{formatDateIT(entry.data)} · {entry.tipo}</option>)}
                      </select>
                    </label>
                  </div>

                  <label className="diagnosisField">
                    <span>Note set fotografico</span>
                    <input className="input" value={photoDraft.note} onChange={(e) => setPhotoDraft({ ...photoDraft, note: e.target.value })} />
                  </label>
                  <label className="diagnosisField">
                    <span>Carica anteprime opzionali</span>
                    <input className="input" type="file" accept="image/*" multiple onChange={(e) => addPhotosToDraft(e.target.files || [])} />
                  </label>

                  {photoDraft.photos.length > 0 && (
                    <div className="photoGrid">
                      {photoDraft.photos.map((photo) => (
                        <div className="photoThumb" key={photo.id}>
                          <img src={photo.dataUrl} alt={photo.name} />
                          <button type="button" onClick={() => setPhotoDraft({ ...photoDraft, photos: photoDraft.photos.filter((p) => p.id !== photo.id) })}>×</button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="photoSaveRow">
                    <Button onClick={savePhotoSession}>Salva set fotografico</Button>
                    <Button secondary onClick={exportPhotoIndexTxt} disabled={(selectedPatient.photoSessions || []).length === 0}>Esporta indice TXT</Button>
                  </div>
                </div>

                {photoSearchDate && (
                  <div className="photoSessionList photoSearchResults">
                    {photoSearchResults.length === 0 ? (
                      <div className="emptyState">Nessuna foto trovata per questa data.</div>
                    ) : (
                      photoSearchResults.map(({ patient, session }) => (
                        <div className="photoSession" key={`search-${patient.id}-${session.id}`}>
                          <div className="sectionHeader compact">
                            <div>
                              <strong>{formatDateIT(session.data)} · {session.tipo}</strong>
                              <p>{patient.cognome || "Cognome"} {patient.nome || "Nome"}{patient.pseudonimo ? ` · ${patient.pseudonimo}` : ""}</p>
                              {session.note && <small>{session.note}</small>}
                            </div>
                            <Button small secondary onClick={() => { setSelectedId(patient.id); setPhotoSearchDate(""); }}>
                              Apri paziente
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {!photoSearchDate && (
                <div className="photoSessionList">
                  {(selectedPatient.photoSessions || []).length === 0 ? (
                    <div className="emptyState">Nessun set fotografico caricato.</div>
                  ) : (
                    <>
                      {(selectedPatient.photoSessions || []).map((session) => {
                        const linkedEntry = (selectedPatient.diario || []).find((entry) => entry.id === session.diarioEntryId);

                        return (
                          <div className="photoSession" key={session.id}>
                            <div className="sectionHeader compact">
                              <div>
                                <div className="photoEditGrid">
                                  <label className="diagnosisField">
                                    <span>Data</span>
                                    <input
                                      className="input"
                                      type="date"
                                      value={session.data || ""}
                                      onChange={(e) => updatePhotoSession(selectedPatient.id, session.id, { data: e.target.value })}
                                    />
                                  </label>
                                  <label className="diagnosisField">
                                    <span>Tipo</span>
                                    <select
                                      className="input"
                                      value={session.tipo || "Foto controllo"}
                                      onChange={(e) => updatePhotoSession(selectedPatient.id, session.id, { tipo: e.target.value })}
                                    >
                                      <option>Foto iniziali</option>
                                      <option>Foto controllo</option>
                                      <option>Foto finali</option>
                                      <option>Urgenza</option>
                                      <option>Contenzione</option>
                                    </select>
                                  </label>
                                </div>
                                {linkedEntry && (
                                  <p className="linkedPhotoInfo">
                                    Appuntamento collegato: {formatDateIT(linkedEntry.data)} · {linkedEntry.tipo}
                                  </p>
                                )}
                                <label className="diagnosisField">
                                  <span>Note</span>
                                  <input
                                    className="input"
                                    value={session.note || ""}
                                    onChange={(e) => updatePhotoSession(selectedPatient.id, session.id, { note: e.target.value })}
                                  />
                                </label>
                              </div>
                              <Button small secondary onClick={() => deletePhotoSession(session.id)}>Elimina set</Button>
                            </div>

                            {session.photos?.length > 0 && (
                              <div className="photoGrid">
                                {session.photos.map((photo) => (
                                  <div className="photoThumb" key={photo.id}>
                                    <img src={photo.dataUrl} alt={photo.name} />
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </>
                  )}
                </div>
                )}
              </Card>
            )}
            {activeTab === "trattamento" && selectedPatient && (
              <Card>
                <div className="sectionHeader">
                  <div>
                    <h2>Stato trattamento</h2>
                    <p>{selectedPatient.cognome || "Cognome"} {selectedPatient.nome || "Nome"}{selectedPatient.pseudonimo ? ` · ${selectedPatient.pseudonimo}` : ""}</p>
                  </div>
                  <Badge>{selectedPatient.trattamento.replaceAll("_", " ")}</Badge>
                </div>

                {(["fissa", "fissa_estetica", "linguale", "allineatori", "intercettiva"].includes(selectedPatient.trattamento)) && (
                  <div className="treatmentSummaryBox">
                    <label className="diagnosisField">
                      <span>Data inizio trattamento attivo</span>
                      <input
                        className="input"
                        type="date"
                        value={selectedPatient.dataInizioTrattamento || ""}
                        onChange={(e) => updatePatient({ dataInizioTrattamento: e.target.value })}
                      />
                    </label>
                    <div className="miniPanel">
                      <span>Tempo trascorso dall'inizio</span>
                      <strong>{monthsLabel(monthsBetweenDates(selectedPatient.dataInizioTrattamento))}</strong>
                    </div>
                  </div>
                )}

                <div className="prefBox">
                  <h3>Note trattamento</h3>
                  <textarea
                    className="textarea"
                    value={selectedPatient.noteTrattamento || ""}
                    onChange={(e) => updatePatient({ noteTrattamento: e.target.value })}
                    placeholder="Note libere sempre modificabili sul trattamento"
                  />
                </div>

                <div className="prefBox">
                  <h3>Obiettivi di trattamento</h3>
                  <textarea
                    className="textarea"
                    value={selectedPatient.diagnosi?.pianoTerapeutico?.obiettivi || ""}
                    onChange={(e) => updateTreatmentPlan({ obiettivi: e.target.value })}
                    placeholder="Obiettivi copiati dalla scheda diagnosi"
                  />
                </div>

                <div className="prefBox nextAppointmentBox">
                  <h3>Prossimo appuntamento</h3>
                  <textarea
                    className="textarea"
                    value={selectedPatient.prossimoAppuntamento || ""}
                    onChange={(e) => updatePatient({ prossimoAppuntamento: e.target.value })}
                    placeholder="Cosa portare o fare al prossimo appuntamento"
                  />
                </div>

                {selectedPatient.trattamento === "studio_caso" && (
                  <div className="caseChecklistBox">
                    <div className="sectionHeader compact">
                      <div>
                        <h3>Checklist studio caso</h3>
                        <p>Documentazione iniziale raccolta per completare lo studio del caso.</p>
                      </div>
                      <Badge>{Object.values({ ...defaultCaseChecklist, ...(selectedPatient.studioCasoChecklist || {}) }).filter(Boolean).length}/5</Badge>
                    </div>
                    <div className="caseChecklistGrid">
                      {Object.entries(caseChecklistLabels).map(([key, label]) => (
                        <label className={`caseChecklistItem ${selectedPatient.studioCasoChecklist?.[key] ? "checked" : ""}`} key={key}>
                          <input
                            type="checkbox"
                            checked={Boolean(selectedPatient.studioCasoChecklist?.[key])}
                            onChange={(e) => updateStudioCaseChecklist(key, e.target.checked)}
                          />
                          <span className="caseCheckIcon">{selectedPatient.studioCasoChecklist?.[key] ? "✓" : ""}</span>
                          <span>{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {isFixedApplianceTreatment(selectedPatient.trattamento) && (
                  <div className="grid2 spaced">
                    <div className="miniPanel">
                      <span>Arco superiore</span>
                      <strong>{getLastDiaryWire(selectedPatient, "sup")}</strong>
                    </div>
                    <div className="miniPanel">
                      <span>Arco inferiore</span>
                      <strong>{getLastDiaryWire(selectedPatient, "inf")}</strong>
                    </div>
                  </div>
                )}

                {selectedPatient.trattamento === "allineatori" && (
                  <>
                    <div className="grid3 spaced">
                      <div className="miniPanel">
                        <span>Ultima consegna</span>
                        <strong>
                          {latestAlignerDelivery
                            ? `${latestAlignerDelivery.alignerDelivery?.da || "?"}-${latestAlignerDelivery.alignerDelivery?.a || "?"}`
                            : "—"}
                        </strong>
                        {latestAlignerDelivery && <small>{formatDateIT(latestAlignerDelivery.data)} · coperto fino a {formatDateIT(latestAlignerDelivery.alignerDelivery?.coveredUntil)}</small>}
                      </div>

                      <div className="miniPanel">
                        <span>Da indossare oggi</span>
                        <strong>{expectedAlignerInfo ? `#${expectedAlignerInfo.row.aligner}` : "—"}</strong>
                        {expectedAlignerInfo && <small>{formatDateIT(expectedAlignerInfo.row.start)} - {formatDateIT(expectedAlignerInfo.row.end)} · {expectedAlignerInfo.status}</small>}
                      </div>

                      <div className="miniPanel">
                        <span>Calendario paziente</span>
                        <Button onClick={exportAlignerCalendarTxt} disabled={!latestAlignerDelivery}>Esporta TXT</Button>
                        <small>File stampabile con tutte le cadenze di cambio.</small>
                      </div>
                    </div>

                    <div className="grid3 spaced">
                      <label className="diagnosisField">
                        <span>Aligner corrente manuale</span>
                        <input className="input" type="number" value={selectedPatient.alignerCorrente} onChange={(e) => updatePatient({ alignerCorrente: Number(e.target.value) })} />
                      </label>
                      <label className="diagnosisField">
                        <span>Aligner totali</span>
                        <input className="input" type="number" value={selectedPatient.alignerTotali} onChange={(e) => updatePatient({ alignerTotali: Number(e.target.value) })} />
                      </label>
                      <Button onClick={() => updatePatient({ alignerCorrente: Math.min(selectedPatient.alignerCorrente + 1, selectedPatient.alignerTotali) })}>Avanza aligner</Button>
                    </div>
                  </>
                )}

                {selectedPatient.trattamento === "contenzione" && (
                  <div className="grid2 spaced">
                    <label className="diagnosisField">
                      <span>Fine trattamento attivo</span>
                      <input className="input" type="date" value={selectedPatient.dataFineTrattamentoAttivo || ""} onChange={(e) => updatePatient({ dataFineTrattamentoAttivo: e.target.value })} />
                    </label>
                    <label className="diagnosisField">
                      <span>Ultimo controllo contenzione</span>
                      <input className="input" type="date" value={selectedPatient.dataUltimoControlloContenzione || ""} onChange={(e) => updatePatient({ dataUltimoControlloContenzione: e.target.value })} />
                    </label>
                    <div className="miniPanel">
                      <span>Ultimo appuntamento registrato</span>
                      <strong>{formatDateIT(getLastAppointment(selectedPatient))}</strong>
                    </div>
                    <div className="miniPanel">
                      <span>Tempo dall'ultimo appuntamento</span>
                      <strong>{monthsLabel(monthsBetweenDates(getLastAppointment(selectedPatient)))}</strong>
                    </div>
                  </div>
                )}

                {selectedPatient.trattamento === "perso" && <div className="emptyState spaced">Paziente segnato come perso / non più visto.</div>}

                <div className="prefBox">
                  <h3>Prescrizione apparecchio</h3>
                  <div className="grid2">
                    <label className="diagnosisField">
                      <span>Data di consegna</span>
                      <input className="input" type="date" value={prescriptionDraft.data} onChange={(e) => setPrescriptionDraft({ ...prescriptionDraft, data: e.target.value })} />
                    </label>
                    <label className="diagnosisField">
                      <span>Laboratorio</span>
                      <select className="input" value={prescriptionDraft.laboratorioId} onChange={(e) => setPrescriptionDraft({ ...prescriptionDraft, laboratorioId: e.target.value })}>
                        {laboratories.map((lab) => <option key={lab.id} value={lab.id}>{lab.nome}</option>)}
                      </select>
                    </label>
                    <label className="diagnosisField fullSpan">
                      <span>Tipo di apparecchio</span>
                      <textarea className="textarea" value={prescriptionDraft.testo} onChange={(e) => setPrescriptionDraft({ ...prescriptionDraft, testo: e.target.value })} placeholder="Es. Ordinare espansore rapido, TEO, contenzione, mantenitore..." />
                    </label>
                  </div>
                  <Button onClick={addPrescription}>Salva prescrizione</Button>

                  <div className="timeline spaced">
                    {(selectedPatient.prescrizioni || []).map((rx) => {
                      const lab = laboratories.find((laboratory) => laboratory.id === rx.laboratorioId);
                      return (
                        <Card key={rx.id}>
                          <div className="sectionHeader compact">
                            <div>
                              <strong>{formatDateIT(rx.data)}</strong>
                              <small>{lab?.nome || rx.laboratorioNome || "Laboratorio non specificato"}</small>
                            </div>
                            <div className="headerActions">
                              <Button small secondary onClick={() => exportPrescriptionTxt(rx)}>TXT</Button>
                              <Button small secondary onClick={() => deletePrescription(rx.id)}>Elimina</Button>
                            </div>
                          </div>
                          <p>{rx.testo}</p>
                        </Card>
                      );
                    })}
                  </div>
                </div>

              </Card>
            )}

            {activeTab === "agenda" && selectedPatient && (
              <Card>
                <div className="sectionHeader">
                  <div>
                    <h2>{agendaView === "settimana" ? "Agenda settimanale" : "Agenda del giorno"}</h2>
                    <p>Crea e controlla appuntamenti e prescrizioni con vista giornaliera o settimanale.</p>
                  </div>
                  <div className="headerActions">
                    <Button secondary onClick={() => setShowMaterialOrders(true)}>
                      Materiali ({materialOrders.filter((item) => item.stato !== "ricevuto").length})
                    </Button>
                    <div className="segmented">
                      <button className={agendaView === "giorno" ? "active" : ""} type="button" onClick={() => setAgendaView("giorno")}>Giorno</button>
                      <button className={agendaView === "settimana" ? "active" : ""} type="button" onClick={() => setAgendaView("settimana")}>Settimana</button>
                    </div>
                    <Badge>{agendaView === "settimana" ? `${formatDateIT(weekDays[0])} - ${formatDateIT(weekDays[6])}` : formatDateIT(agendaDate)}</Badge>
                  </div>
                </div>

                <div className="agendaTwoColumn">
                  <div className="agendaBuilder">
                  <div className="agendaRow agendaDateTime">
                    <label>
                      <span>Giorno</span>
                      <input className="input" type="date" value={agendaDate} onChange={(e) => setAgendaDate(e.target.value)} />
                    </label>

                    <label>
                      <span>Ora</span>
                      <input className="input" type="time" value={newAgendaItem.ora} onChange={(e) => setNewAgendaItem({ ...newAgendaItem, ora: e.target.value })} />
                    </label>
                  </div>

                  <label className="agendaRow">
                    <span>Studio</span>
                    <input className="input" value={selectedStudio?.nome || "Studio non indicato"} readOnly />
                  </label>

                  <label className="agendaRow">
                    <span>Motivo</span>
                    <input className="input" value={agendaReason} onChange={(e) => setNewAgendaItem({ ...newAgendaItem, patientId: selectedPatient.id, motivo: e.target.value })} />
                  </label>

                  <Button onClick={addAgendaItem}>+ Aggiungi in agenda</Button>

                  <div className="agendaImportBox">
                    <h3>Importa calendario</h3>
                    <div className="databaseButtonGrid twoCols">
                      <label className="fileButton">
                        Carica file .ics
                        <input type="file" accept=".ics,text/calendar" onChange={(e) => importIcsFromFile(e.target.files?.[0])} />
                      </label>
                      <Button secondary onClick={() => { setIcsEvents([]); setIcsAssignments({}); setIcsSearches({}); }}>
                        Svuota import
                      </Button>
                    </div>

                    {icsEvents.length === 0 ? (
                      <div className="emptyState compactEmpty">Nessun evento ICS da associare.</div>
                    ) : (
                      <div className="icsImportList">
                        {icsEvents.map((event) => {
                          const search = icsSearches[event.id] || "";
                          const matches = patients
                            .filter((p) => matchesSearchQuery(`${p.nome} ${p.cognome} ${p.pseudonimo} ${p.codiceFiscale}`, search))
                            .slice(0, 8);
                          const assignedPatient = patients.find((p) => p.id === icsAssignments[event.id]);

                          return (
                            <div className="icsImportItem" key={event.id}>
                              <div>
                                <strong>{formatDateIT(event.data)} · {event.ora}</strong>
                                <p>{event.titolo}</p>
                                {event.luogo && <small>{event.luogo}</small>}
                              </div>

                              <div className="icsAssignBox">
                                <input
                                  className="input"
                                  placeholder="Cerca paziente da associare"
                                  value={search}
                                  onChange={(e) => setIcsSearches({ ...icsSearches, [event.id]: e.target.value })}
                                />
                                {assignedPatient && <Badge>Associato a {assignedPatient.cognome} {assignedPatient.nome}</Badge>}
                                {search && (
                                  <div className="icsMatches">
                                    {matches.map((p) => (
                                      <button
                                        type="button"
                                        key={p.id}
                                        className="icsMatchButton"
                                        onClick={() => setIcsAssignments({ ...icsAssignments, [event.id]: p.id })}
                                      >
                                        {p.cognome || "Cognome"} {p.nome || "Nome"}{p.pseudonimo ? ` · ${p.pseudonimo}` : ""}
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>

                              <div className="icsActions">
                                <Button small onClick={() => acceptIcsEvent(event)} disabled={!icsAssignments[event.id]}>
                                  Importa in agenda
                                </Button>
                                <Button small secondary onClick={() => discardIcsEvent(event.id)}>
                                  Ignora
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                  </div>

                  <div className="agendaDayPanel">
                    {agendaView === "giorno" ? (
                      <>
                        <h3>Agenda del giorno</h3>
                        <div className="agendaList">
                          {dayAgenda.length === 0 && dayPrescriptions.length === 0 && agendaDate !== localDateISO(agendaNow) ? (
                            <div className="emptyState">
                              Nessun appuntamento o prescrizione inserita per questa data.
                            </div>
                          ) : (
                            <>
                              {agendaTimeline(dayAgenda, agendaDate, agendaNow).map((item) => {
                                if (item.isNow) return <div className="agendaNowLine" key={item.id}><span>Adesso · {item.ora}</span></div>;
                                const p = patients.find((patient) => patient.id === item.patientId);

                                return (
                                  <div className="agendaItem" key={item.id}>
                                    <div className="agendaTime">{item.ora}</div>

                                    <div className="agendaMain">
                                      <strong>{p?.cognome || "Cognome"} {p?.nome || "Nome"}</strong>
                                      <input
                                        aria-label="Motivo appuntamento"
                                        className="input agendaReasonInput"
                                        value={item.motivo || ""}
                                        onChange={(e) => updateAgendaItem(item.id, { motivo: e.target.value })}
                                      />
                                    </div>

                                    <Button
                                      small
                                      secondary
                                      onClick={() => {
                                        if (p) {
                                          setSelectedId(p.id);
                                          setActiveTab("diario");
                                        }
                                      }}
                                    >
                                      Apri
                                    </Button>

                                    <Button small secondary onClick={() => deleteAgendaItem(item.id)}>
                                      Elimina
                                    </Button>
                                  </div>
                                );
                              })}

                              {dayPrescriptions.map((rx) => (
                                <div className="agendaItem prescriptionAgendaItem" key={`rx-agenda-${rx.id}`}>
                                  <div className="agendaTime">RX</div>

                                  <div className="agendaMain">
                                    <strong>{rx.patient?.cognome || "Cognome"} {rx.patient?.nome || "Nome"}</strong>
                                    <span>Prescrizione apparecchio: {rx.testo}</span>
                                    <small>Laboratorio: {laboratories.find((lab) => lab.id === rx.laboratorioId)?.nome || rx.laboratorioNome || "Non specificato"}</small>
                                    <label className="rxArrivedCheck">
                                      <input
                                        type="checkbox"
                                        checked={Boolean(rx.arrivato)}
                                        onChange={(e) => updatePrescriptionStatus(rx.patient.id, rx.id, { arrivato: e.target.checked, dataArrivo: e.target.checked ? new Date().toISOString().slice(0, 10) : "" })}
                                      />
                                      <small>{rx.arrivato ? `Arrivato il ${formatDateIT(rx.dataArrivo)}` : "Non ancora arrivato"}</small>
                                    </label>
                                  </div>

                                  <Button
                                    small
                                    secondary
                                    onClick={() => {
                                      setSelectedId(rx.patient.id);
                                      setActiveTab("trattamento");
                                    }}
                                  >
                                    Apri
                                  </Button>

                                  <span />
                                </div>
                              ))}
                            </>
                          )}
                        </div>
                      </>
                    ) : (
                      <div className="weekGrid">
                        {weekAgendaByDate.map(({ date, appointments, prescriptions }) => (
                          <div className="weekDay" key={date}>
                            <button className={`weekDayHeader ${date === agendaDate ? "active" : ""}`} type="button" onClick={() => setAgendaDate(date)}>
                              <strong>{weekdayLabel(date)}</strong>
                              <span>{formatDateIT(date)}</span>
                            </button>
                            <div className="weekDayItems">
                              {appointments.length === 0 && prescriptions.length === 0 && date !== localDateISO(agendaNow) ? (
                                <small className="muted">Vuoto</small>
                              ) : (
                                <>
                                  {agendaTimeline(appointments, date, agendaNow).map((item) => {
                                    if (item.isNow) return <div className="agendaNowLine" key={item.id}><span>Adesso · {item.ora}</span></div>;
                                    const p = patients.find((patient) => patient.id === item.patientId);
                                    return (
                                      <div className="weekAppointment" key={item.id}>
                                        <strong>{item.ora}</strong>
                                        <span>{p?.cognome || "Cognome"} {p?.nome || "Nome"}</span>
                                        <input
                                          aria-label="Motivo appuntamento"
                                          className="weekReasonInput"
                                          value={item.motivo || ""}
                                          onChange={(e) => updateAgendaItem(item.id, { motivo: e.target.value })}
                                        />
                                        <Button small secondary onClick={() => { if (p) { setSelectedId(p.id); setActiveTab("diario"); } }}>Apri</Button>
                                      </div>
                                    );
                                  })}
                                  {prescriptions.map((rx) => (
                                    <button className="weekAppointment prescription" key={`week-rx-${rx.id}`} type="button" onClick={() => { setSelectedId(rx.patient.id); setActiveTab("trattamento"); }}>
                                      <strong>RX</strong>
                                      <span>{rx.patient?.cognome || "Cognome"} {rx.patient?.nome || "Nome"}</span>
                                      <small>{rx.testo}</small>
                                      <small>{laboratories.find((lab) => lab.id === rx.laboratorioId)?.nome || rx.laboratorioNome || "Lab non indicato"}</small>
                                    </button>
                                  ))}
                                </>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <details className="agendaRecallPanel">
                  <summary>
                    <span>Recall</span>
                    <strong>{recallItems.length} pazienti</strong>
                  </summary>

                  <div className="recallFilters">
                    <label className="diagnosisField">
                      <span>Tipologia trattamento</span>
                      <select className="input" value={recallTreatmentFilter} onChange={(e) => setRecallTreatmentFilter(e.target.value)}>
                        <option value="all">Tutti tranne persi</option>
                        <option value="active">In trattamento</option>
                        <option value="studio_caso">Studio caso</option>
                        <option value="contenzione">Contenzione</option>
                        <option value="intercettiva">Intercettiva</option>
                        <option value="allineatori">Allineatori</option>
                        <option value="fissa">Fissa tradizionale</option>
                        <option value="fissa_estetica">Fissa estetica</option>
                        <option value="linguale">Linguale</option>
                      </select>
                    </label>

                    <label className="diagnosisField">
                      <span>Ultimo appuntamento</span>
                      <select className="input" value={recallMonthFilter} onChange={(e) => setRecallMonthFilter(e.target.value)}>
                        <option value="2">Non visti da 2+ mesi</option>
                        <option value="6">Non visti da 6+ mesi</option>
                        <option value="12">Non visti da 12+ mesi</option>
                        <option value="24">Non visti da 24+ mesi</option>
                        <option value="all">Tutti</option>
                      </select>
                    </label>

                    <label className="diagnosisField">
                      <span>Studio</span>
                      <select className="input" value={recallStudioFilter} onChange={(e) => setRecallStudioFilter(e.target.value)}>
                        <option value="all">Tutti gli studi</option>
                        {studios.map((studio) => <option key={studio.id} value={studio.id}>{studio.nome}</option>)}
                      </select>
                    </label>

                    <label className="checkRow recallExcludedToggle">
                      <input type="checkbox" checked={showExcludedRecall} onChange={(e) => setShowExcludedRecall(e.target.checked)} />
                      <span>Mostra esclusi</span>
                    </label>
                  </div>

                  <div className="recallList">
                    {recallItems.length === 0 ? (
                      <div className="emptyState">Nessun paziente trovato con questi filtri.</div>
                    ) : (
                      recallItems.map(({ patient, lastAppointment, monthsSinceLastAppointment, isNeverSeen }) => (
                        <div className={`recallItem ${patient.esclusoRecall ? "excluded" : ""}`} key={patient.id}>
                          <div className="recallAge">
                            <strong>{isNeverSeen ? "Mai" : monthsLabel(monthsSinceLastAppointment)}</strong>
                            <span>{isNeverSeen ? "nessun diario" : "dall'ultimo controllo"}</span>
                          </div>

                          <div className="recallMain">
                            <strong>{patient.cognome || "Cognome"} {patient.nome || "Nome"}</strong>
                            <span>{treatmentLabel(patient.trattamento)}{patient.pseudonimo ? ` · ${patient.pseudonimo}` : ""}</span>
                            <small>Studio: {studios.find((studio) => studio.id === patient.studioId)?.nome || "Studio non indicato"}</small>
                            <small>Ultimo appuntamento: {formatDateIT(lastAppointment)}</small>
                            {getNextAppointment(patient.id) && <small>Prossimo appuntamento: {formatDateIT(getNextAppointment(patient.id).data)} ore {getNextAppointment(patient.id).ora}</small>}
                          </div>

                          <label className="checkRow recallExcludeCheck">
                            <input
                              type="checkbox"
                              checked={Boolean(patient.esclusoRecall)}
                              onChange={(e) => {
                                setPatients((currentPatients) => currentPatients.map((p) => p.id === patient.id ? { ...p, esclusoRecall: e.target.checked } : p));
                              }}
                            />
                            <span>Escludi</span>
                          </label>

                          <Button
                            small
                            secondary
                            onClick={() => {
                              setSelectedId(patient.id);
                              setActiveTab("trattamento");
                            }}
                          >
                            Apri
                          </Button>

                          <Button
                            small
                            secondary
                            onClick={() => deletePatient(patient.id)}
                          >
                            Elimina
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </details>
              </Card>
            )}

            {showMaterialOrders && (
              <div className="materialDrawerLayer" role="dialog" aria-modal="true" aria-label="Materiali da ordinare">
                <button className="materialDrawerBackdrop" type="button" onClick={() => setShowMaterialOrders(false)} aria-label="Chiudi materiali" />
                <aside className="materialDrawer">
                  <div className="materialDrawerHeader">
                    <div>
                      <h2>Materiali da ordinare</h2>
                      <small>{materialOrders.filter((item) => item.stato !== "ricevuto").length} elementi attivi</small>
                    </div>
                    <button className="materialDrawerClose" type="button" onClick={() => setShowMaterialOrders(false)} title="Chiudi" aria-label="Chiudi">×</button>
                  </div>

                  <div className="materialDraftBox">
                    <div className="materialDraftGrid">
                      <label className="diagnosisField fullSpan">
                        <span>Materiale</span>
                        <input className="input" value={materialDraft.nome} onChange={(e) => setMaterialDraft({ ...materialDraft, nome: e.target.value })} placeholder="Es. attacchi, fili, elastici..." />
                      </label>
                      <label className="diagnosisField">
                        <span>Quantità</span>
                        <input className="input" type="number" min="1" value={materialDraft.quantita} onChange={(e) => setMaterialDraft({ ...materialDraft, quantita: e.target.value })} />
                      </label>
                      <label className="diagnosisField">
                        <span>Urgenza</span>
                        <select className="input" value={materialDraft.urgenza} onChange={(e) => setMaterialDraft({ ...materialDraft, urgenza: e.target.value })}>
                          <option value="normale">Normale</option>
                          <option value="urgente">Urgente</option>
                        </select>
                      </label>
                      <label className="diagnosisField">
                        <span>Studio</span>
                        <select className="input" value={materialDraft.studioId} onChange={(e) => setMaterialDraft({ ...materialDraft, studioId: e.target.value })}>
                          {studios.map((studio) => <option key={studio.id} value={studio.id}>{studio.nome}</option>)}
                        </select>
                      </label>
                      <label className="diagnosisField">
                        <span>Laboratorio / fornitore</span>
                        <select className="input" value={materialDraft.supplierId} onChange={(e) => setMaterialDraft({ ...materialDraft, supplierId: e.target.value })}>
                          {laboratories.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.nome}</option>)}
                        </select>
                      </label>
                      <label className="diagnosisField fullSpan">
                        <span>Paziente collegato (facoltativo)</span>
                        <select className="input" value={materialDraft.patientId} onChange={(e) => setMaterialDraft({ ...materialDraft, patientId: e.target.value })}>
                          <option value="">Nessun paziente</option>
                          {[...patients]
                            .sort((a, b) => `${a.cognome} ${a.nome}`.localeCompare(`${b.cognome} ${b.nome}`))
                            .map((patient) => <option key={patient.id} value={patient.id}>{patient.cognome || "Cognome"} {patient.nome || "Nome"}</option>)}
                        </select>
                      </label>
                      <label className="diagnosisField fullSpan">
                        <span>Note</span>
                        <textarea className="textarea materialNotesInput" value={materialDraft.note} onChange={(e) => setMaterialDraft({ ...materialDraft, note: e.target.value })} />
                      </label>
                    </div>
                    <Button onClick={addMaterialOrder} disabled={!materialDraft.nome.trim()}>Aggiungi alla lista</Button>
                  </div>

                  <div className="materialFilters">
                    <label className="diagnosisField">
                      <span>Filtra per studio</span>
                      <select className="input" value={materialStudioFilter} onChange={(e) => setMaterialStudioFilter(e.target.value)}>
                        <option value="all">Tutti gli studi</option>
                        {studios.map((studio) => <option key={studio.id} value={studio.id}>{studio.nome}</option>)}
                      </select>
                    </label>
                    <label className="checkRow">
                      <input type="checkbox" checked={showReceivedMaterials} onChange={(e) => setShowReceivedMaterials(e.target.checked)} />
                      <span>Mostra ricevuti</span>
                    </label>
                  </div>

                  <div className="materialOrderList">
                    {visibleMaterialOrders.length === 0 ? (
                      <div className="emptyState">Nessun materiale in questa vista.</div>
                    ) : visibleMaterialOrders.map((item) => {
                      const studio = studios.find((entry) => entry.id === item.studioId);
                      const supplier = laboratories.find((entry) => entry.id === item.supplierId);
                      const patient = patients.find((entry) => entry.id === item.patientId);
                      return (
                        <div className={`materialOrderItem ${item.stato === "ricevuto" ? "received" : ""}`} key={item.id}>
                          <div className="materialOrderMain">
                            <div className="materialOrderTitle">
                              <strong>{item.nome}</strong>
                              <Badge>× {item.quantita}</Badge>
                              {item.urgenza === "urgente" && <span className="urgentMaterial">Urgente</span>}
                            </div>
                            <small>{supplier?.nome || "Fornitore non indicato"} · {studio?.nome || "Studio non indicato"}</small>
                            {patient && <small>Paziente: {patient.cognome} {patient.nome}</small>}
                            {item.note && <p>{item.note}</p>}
                          </div>
                          <div className="materialOrderActions">
                            <select className="input" value={item.stato || "da_ordinare"} onChange={(e) => updateMaterialOrder(item.id, { stato: e.target.value })}>
                              <option value="da_ordinare">Da ordinare</option>
                              <option value="ordinato">Ordinato</option>
                              <option value="ricevuto">Ricevuto</option>
                            </select>
                            <Button small secondary onClick={() => deleteMaterialOrder(item.id)}>Elimina</Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </aside>
              </div>
            )}

            {activeTab === "preferenze" && (
              <Card>
                <h2>Preferenze</h2>

                <div className="versionBox">
                  <div>
                    <span>Versione app</span>
                    <strong>{appVersion}</strong>
                  </div>
                  <small>Web · Release {appReleaseDate}</small>
                </div>

                {!demo && <div className="prefBox">
                  <h3>Sicurezza</h3>
                  <div className="grid3">
                    <label className="diagnosisField">
                      <span>Password attuale</span>
                      <input className="input" type="password" value={authDraft.currentPassword} onChange={(e) => setAuthDraft({ ...authDraft, currentPassword: e.target.value })} />
                    </label>
                    <label className="diagnosisField">
                      <span>Nuova password</span>
                      <input className="input" type="password" value={authDraft.newPassword} onChange={(e) => setAuthDraft({ ...authDraft, newPassword: e.target.value })} />
                    </label>
                    <label className="diagnosisField">
                      <span>Ripeti nuova password</span>
                      <input className="input" type="password" value={authDraft.confirmNewPassword} onChange={(e) => setAuthDraft({ ...authDraft, confirmNewPassword: e.target.value })} />
                    </label>
                  </div>
                  <div className="securityActions">
                    <Button secondary onClick={changePassword}>Cambia password</Button>
                    <Button secondary onClick={lockApp}>Blocca ora</Button>
                  </div>
                  {authMessage && <small className="authMessage">{authMessage}</small>}
                  <small>Blocco automatico dopo 15 minuti di inattività. La password non viene salvata in chiaro; i dati nel browser non sono cifrati.</small>
                </div>}

                <div className="prefBox">
                  <h3>Archivio nel browser</h3>
                  <p>{demo ? "Stai usando dati dimostrativi temporanei." : "Schede e foto sono salvate solo su questo browser, senza sincronizzazione."}</p>
                  <small>Cancellando i dati del sito, l’archivio viene eliminato. La password non cifra i dati salvati. Esporta un backup per conservarne una copia.</small>
                  {!demo && <Button secondary onClick={async () => {
                    try {
                      const granted = await requestArchivePersistence();
                      alert(granted ? "Il browser ha concesso la conservazione persistente. Conserva comunque un backup." : "Il browser non ha concesso la conservazione persistente. Esporta regolarmente un backup.");
                    } catch { alert("Non è possibile richiedere la conservazione persistente su questo browser."); }
                  }}>Richiedi conservazione dei dati</Button>}
                </div>
                <div className="prefBox">
                  <h3>Studi</h3>
                  <div className="row">
                    <input className="input" placeholder="Nome nuovo studio" value={newStudioName} onChange={(e) => setNewStudioName(e.target.value)} />
                    <Button onClick={addStudio}>Aggiungi</Button>
                  </div>
                  <div className="studioEditorList">
                    {studios.map((s) => (
                      <div className="studioEditorItem" key={s.id}>
                        <input className="input" value={s.nome} onChange={(e) => updateStudio(s.id, { nome: e.target.value })} />
                        <input className="input" value={s.indirizzo || ""} onChange={(e) => updateStudio(s.id, { indirizzo: e.target.value })} placeholder="Indirizzo" />
                        <Button small secondary onClick={() => deleteStudio(s.id)}>Cancella</Button>
                      </div>
                    ))}
                  </div>
                  <small>Non puoi cancellare l’ultimo studio. I pazienti vengono riassegnati al primo studio disponibile.</small>
                </div>

                <div className="prefBox">
                  <h3>Laboratori e fornitori</h3>
                  <div className="row">
                    <input className="input" placeholder="Nome laboratorio o fornitore" value={newLaboratoryName} onChange={(e) => setNewLaboratoryName(e.target.value)} />
                    <Button onClick={addLaboratory}>Aggiungi</Button>
                  </div>
                  <div className="studioEditorList">
                    {laboratories.map((lab) => (
                      <div className="laboratoryEditorItem" key={lab.id}>
                        <input className="input" value={lab.nome} onChange={(e) => updateLaboratory(lab.id, { nome: e.target.value })} />
                        <Button small secondary onClick={() => deleteLaboratory(lab.id)}>Cancella</Button>
                      </div>
                    ))}
                  </div>
                  <small>Non puoi cancellare l’ultimo elemento. Prescrizioni e materiali collegati vengono riassegnati al primo disponibile.</small>
                </div>

                <div className="prefBox">
                  <h3>Database</h3>
                  <label className="checkRow backupEncryptionToggle">
                    <input
                      type="checkbox"
                      checked={encryptBackups}
                      disabled={demo}
                      onChange={(e) => setEncryptBackups(e.target.checked)}
                    />
                    <span>Cifra backup JSON</span>
                  </label>
                  <small className="saveDestinationNote">
                    Se attivo, il file salvato da <strong>Salva</strong> viene cifrato con la password dell’app. Conserva la password: senza non si può recuperare il backup.
                  </small>
                  <div className="saveDestinationBox">
                    <div>
                      <strong>Destinazione salvataggio JSON</strong>
                      <small>{saveFileName || "Nessun file fisso selezionato: Salva scaricherà un nuovo backup."}</small>
                    </div>
                    <Button secondary onClick={chooseDatabaseSaveFile}>
                      {saveFileName ? "Cambia file" : "Scegli file"}
                    </Button>
                  </div>
                  <small className="saveDestinationNote">Nel selettore del Mac puoi scegliere una cartella di iCloud Drive. Il browser potrebbe chiedere nuovamente il permesso dopo un riavvio.</small>
                  <label className="diagnosisField">
                    <span>Password backup cifrato</span>
                    <input
                      className="input"
                      type="password"
                      value={importPassword}
                      onChange={(e) => setImportPassword(e.target.value)}
                      placeholder="Solo per caricare backup cifrati"
                    />
                  </label>
                  <div className="databaseButtonGrid twoCols">
                    <Button secondary onClick={importDatabase}>Sostituisci database</Button>
                    <Button secondary onClick={mergeDatabase}>Merge database</Button>
                  </div>
                  <textarea className="textarea tall" placeholder="Incolla qui un backup JSON oppure caricalo dal pulsante file" value={importText} onChange={(e) => setImportText(e.target.value)} />
                  <small>I pulsanti <strong>Salva</strong> e <strong>Carica</strong> sono ora in alto. <strong>Carica</strong> sostituisce il database con il file scelto; <strong>Sostituisci database</strong> usa il testo incollato; <strong>Merge</strong> unisce i dati aggiornando i pazienti con lo stesso ID.</small>
                </div>

                <div className="prefBox">
                  <h3>Wire sequence fissa tradizionale</h3>
                  <textarea className="textarea tall" value={wireSequence.join("\n")} onChange={(e) => setWireSequence(e.target.value.split("\n").filter(Boolean))} />
                  <small>Una riga per arco. Il primo valore consigliato è --- per arcata non bondata.</small>
                </div>

                <div className="prefBox">
                  <h3>Wire sequence linguale</h3>
                  <textarea className="textarea tall" value={lingualWireSequence.join("\n")} onChange={(e) => setLingualWireSequence(e.target.value.split("\n").filter(Boolean))} />
                  <small>Sequenza separata per trattamento linguale.</small>
                </div>
              </Card>
            )}
          </main>
        </div>
      </div>
    </>
  );
}

const css = `
  * { box-sizing: border-box; }
  body { margin: 0; font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #e8eef0; color: #0f172a; }
  .lockScreen { min-height: 100vh; display: grid; place-items: center; padding: 22px; background: #e8eef0; }
  .lockCard { width: min(420px, 100%); display: flex; flex-direction: column; gap: 12px; border: 1px solid #c7e2df; border-radius: 24px; background: white; padding: 28px; box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12); }
  .lockCard h1 { font-size: 28px; color: #0f766e; }
  .lockCard p { margin: 0 0 6px; }
  .lockMark { width: 58px; height: 58px; display: grid; place-items: center; border-radius: 16px; background: #0f766e; color: white; font-weight: 900; }
  .authMessage { display: block; color: #b45309; font-weight: 800; }
  .privacyNote { color: #64748b; line-height: 1.45; }
  .app { min-height: 100vh; padding: 28px; max-width: 1500px; margin: 0 auto; }
  .header { display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 24px; }
  .storageWarning { margin-top: 10px; border: 1px solid #f59e0b; background: #fffbeb; color: #92400e; border-radius: 12px; padding: 9px 11px; font-size: 13px; font-weight: 800; }
  .topDatabaseActions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
  .topActionButton { min-width: 112px; min-height: 42px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #93b9e8; border-radius: 16px; background: #eaf4ff; color: #1d4ed8; padding: 11px 16px; font: inherit; font-weight: 700; line-height: 1; cursor: pointer; text-align: center; transition: 0.15s ease; }
  .topActionButton:hover { transform: translateY(-1px); opacity: 0.92; }
  .topActionButton input { display: none; }
  h1 { margin: 0; font-size: 34px; letter-spacing: 0; color: #0f766e; }
  h2 { margin: 0 0 16px; font-size: 22px; }
  h3 { margin: 0 0 12px; }
  p { color: #475569; line-height: 1.5; }
  .layout { display: grid; grid-template-columns: 360px 1fr; gap: 20px; }
  .layout.fullWidth { grid-template-columns: 1fr; }
  .card { background: white; border-radius: 24px; padding: 22px; box-shadow: 0 14px 40px rgba(15, 23, 42, 0.08); border: 1px solid #d6e4e7; }
  .btn { border: 0; border-radius: 16px; background: #0f766e; color: white; padding: 11px 16px; font-weight: 700; cursor: pointer; transition: 0.15s ease; }
  .btn:hover { transform: translateY(-1px); opacity: 0.92; }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btnSecondary { background: white; color: #164e63; border: 1px solid #a9c8d1; }
  .btnSmall { padding: 8px 11px; border-radius: 12px; font-size: 12px; }
  .input, .textarea, select { width: 100%; border: 1px solid #bfd1d6; border-radius: 14px; padding: 12px 13px; font: inherit; background: white; }
  .input:focus, .textarea:focus, select:focus { outline: 3px solid #ccfbf1; border-color: #14b8a6; }
  .textarea { min-height: 120px; resize: vertical; }
  .tall { min-height: 190px; }
  .smallInput { width: 130px; padding: 8px 10px; }
  .tabs { display: grid; grid-template-columns: repeat(6, 1fr); background: #cfe2e7; padding: 5px; border-radius: 18px; margin-bottom: 16px; gap: 5px; }
  .tab { border: 0; border-radius: 14px; padding: 11px; background: transparent; font-weight: 800; cursor: pointer; text-transform: capitalize; color: #334155; }
  .activeTab { background: #ecfeff; color: #0f766e; box-shadow: 0 6px 14px rgba(15, 118, 110, 0.16); }
  .patientList { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; }
  .patientButton { text-align: left; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 14px; cursor: pointer; display: flex; flex-direction: column; gap: 4px; }
  .patientButton span, .patientButton small { color: #64748b; }
  .patientButton.active { background: #155e75; color: white; border-color: #155e75; }
  .patientButton.active span, .patientButton.active small { color: #cbd5e1; }
  .patientPickerBar { position: relative; display: grid; grid-template-columns: minmax(220px, 1fr) auto minmax(260px, 1.4fr) minmax(180px, 0.7fr); gap: 12px; align-items: center; margin-bottom: 16px; padding: 14px; border: 1px solid #c7e2df; border-radius: 18px; background: white; box-shadow: 0 12px 30px rgba(15, 23, 42, 0.06); }
  .selectedPatientSummary { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
  .selectedPatientSummary span { color: #64748b; font-size: 12px; font-weight: 900; text-transform: uppercase; }
  .selectedPatientSummary strong { overflow: hidden; font-size: 18px; text-overflow: ellipsis; white-space: nowrap; }
  .selectedPatientSummary small { color: #64748b; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .globalPatientMatches { position: absolute; z-index: 20; top: calc(100% + 8px); left: 14px; right: 14px; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px; padding: 12px; border: 1px solid #c7e2df; border-radius: 18px; background: white; box-shadow: 0 18px 40px rgba(15, 23, 42, 0.14); }
  .sheetOverlay { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 24px; background: rgba(15, 23, 42, 0.34); }
  .sheetPanel { width: min(980px, 100%); max-height: calc(100vh - 48px); overflow: auto; border: 1px solid #d6e4e7; border-radius: 24px; background: white; padding: 22px; box-shadow: 0 24px 70px rgba(15, 23, 42, 0.24); }
  .grid2 { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
  .grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; align-items: center; }
  .grid4 { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; align-items: center; }
  .spaced { margin-top: 22px; }
  .sectionHeader { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; margin-bottom: 18px; }
  .sectionHeader p { margin: 4px 0 0; }
  .headerActions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
  .compact { margin-bottom: 8px; }
  .badge { display: inline-flex; align-items: center; border-radius: 999px; background: #fff7dd; color: #854d0e; padding: 6px 10px; font-size: 12px; font-weight: 800; }
  .chips { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
  .sliderHeader { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; gap: 12px; }
  .scorePill { background: #155e75; color: white; padding: 6px 10px; border-radius: 999px; font-size: 12px; font-weight: 800; }
  .range { width: 100%; accent-color: #0f766e; }
  .diagnosisField { display: flex; flex-direction: column; gap: 6px; }
  .diagnosisField span { font-size: 13px; font-weight: 800; color: #475569; }
  .fullSpan { grid-column: 1 / -1; }
  .diagnosisTextGrid { display: grid; grid-template-columns: 1fr; gap: 14px; margin-top: 18px; }
  .therapyPlanBox { margin-top: 24px; padding: 18px; border: 1px solid #c7e2df; border-radius: 18px; background: #f0fdfa; display: flex; flex-direction: column; gap: 14px; }
  .diagnosisExportActions { display: flex; gap: 10px; flex-wrap: wrap; }
  .quoteGrid { display: grid; grid-template-columns: minmax(220px, 0.7fr) minmax(320px, 1.3fr); gap: 14px; align-items: start; }
  .quoteAmountColumn { display: flex; flex-direction: column; gap: 9px; }
  .quoteEstimateDetails { position: relative; }
  .quoteEstimateDetails > summary { width: 28px; height: 28px; display: grid; place-items: center; border: 1px solid #99c9c2; border-radius: 50%; background: white; color: #0f766e; font-size: 15px; font-weight: 900; cursor: pointer; list-style: none; }
  .quoteEstimateDetails > summary::-webkit-details-marker { display: none; }
  .quoteEstimateDetails[open] > summary { background: #0f766e; color: white; }
  .quoteEstimatePanel { margin-top: 9px; padding: 12px; border: 1px solid #bfe0e7; border-radius: 14px; background: white; display: flex; flex-direction: column; gap: 12px; }
  .quoteEstimateGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .quoteEstimateResult { border-left: 4px solid #0f766e; border-radius: 0 12px 12px 0; background: #ecfdf5; padding: 11px 12px; display: flex; flex-direction: column; gap: 3px; }
  .quoteEstimateResult > span { color: #047857; font-size: 12px; font-weight: 900; text-transform: uppercase; }
  .quoteEstimateResult > strong { color: #0f172a; font-size: 23px; }
  .quoteEstimateBreakdown { display: flex; flex-direction: column; gap: 2px; margin-top: 6px; }
  .quoteEstimateEmpty { display: block; color: #64748b; padding: 3px 1px; }
  .quoteEstimateWarning { border: 1px solid #fbbf24; border-radius: 12px; background: #fffbeb; color: #92400e; padding: 10px; font-size: 13px; font-weight: 800; }
  .paymentDetails { border: 1px solid #e2e8f0; background: white; border-radius: 16px; overflow: hidden; }
  .paymentDetails summary { cursor: pointer; padding: 12px 14px; font-weight: 900; color: #0f172a; }
  .paymentDetails[open] summary { border-bottom: 1px solid #e2e8f0; }
  .paymentCalculator { display: flex; flex-direction: column; gap: 14px; padding: 14px; }
  .paymentOutput { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 13px; background: #f8fafc; }
  .diaryPatientHeader { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 16px; background: white; border: 1px solid #e2e8f0; border-radius: 24px; padding: 18px 22px; box-shadow: 0 14px 40px rgba(15, 23, 42, 0.08); }
  .diaryPatientHeader h2 { margin: 0; }
  .diaryPatientHeader p { margin: 4px 0 0; }
  .diaryGrid { display: grid; grid-template-columns: minmax(0, 1fr) 420px; gap: 16px; }
  .diaryDateField { display: flex; flex-direction: column; gap: 6px; margin-bottom: 10px; }
  .diaryDateField span { font-size: 13px; font-weight: 800; color: #475569; }
  .diaryEntryActions { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-top: 12px; }
  .diaryEntryActions small { color: #64748b; font-weight: 700; }
  .diaryCompactRow { width: 100%; border: 0; background: transparent; padding: 0; display: flex; justify-content: space-between; align-items: center; gap: 12px; text-align: left; cursor: pointer; }
  .selectedDiaryRow strong { color: #0f766e; }
  .diaryCompactRow div:first-child { display: flex; flex-direction: column; gap: 3px; }
  .diaryCompactRow span { color: #64748b; font-size: 13px; }
  .diaryWireSummary { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
  .diaryFullCard { border-top: 1px solid #e2e8f0; margin-top: 14px; padding-top: 14px; }
  .diaryPreviewText { margin: 0 0 10px; color: #334155; white-space: pre-wrap; }
  .timeline { display: flex; flex-direction: column; gap: 12px; }
  .miniPanel { border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 18px; display: flex; flex-direction: column; gap: 12px; }
  .miniPanel span { color: #64748b; }
  .miniPanel strong { font-size: 24px; }
  .wireButtons { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
  .wireButtons.wide { grid-column: 1 / -1; }
  .prefBox { border: 1px solid #d5dce9; background: #f6f8fc; border-radius: 18px; padding: 16px; margin-top: 14px; }
  .versionBox { display: flex; justify-content: space-between; align-items: center; gap: 14px; border: 1px solid #bfe0e7; background: #f0fdfa; border-radius: 18px; padding: 14px 16px; margin-top: 8px; }
  .versionBox div { display: flex; flex-direction: column; gap: 3px; }
  .versionBox span, .versionBox small { color: #64748b; font-size: 13px; font-weight: 800; }
  .versionBox strong { color: #0f766e; font-size: 26px; line-height: 1; }
  .securityActions { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
  .saveDestinationBox { display: flex; justify-content: space-between; align-items: center; gap: 14px; padding: 12px; margin-bottom: 8px; border: 1px solid #bfe0e7; border-radius: 14px; background: white; }
  .saveDestinationBox div { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
  .saveDestinationBox small { color: #475569; overflow-wrap: anywhere; }
  .saveDestinationNote { display: block; margin-bottom: 14px; color: #64748b; }
  .caseChecklistBox { border: 1px solid #dbeafe; background: linear-gradient(180deg, #f8fafc 0%, #eff6ff 100%); border-radius: 18px; padding: 16px; margin-top: 14px; }
  .caseChecklistGrid { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 10px; }
  .caseChecklistItem { background: white; border: 1px solid #dbeafe; border-radius: 14px; padding: 12px; display: grid; grid-template-columns: 26px 1fr; align-items: center; gap: 10px; cursor: pointer; font-weight: 800; color: #334155; transition: 0.15s ease; }
  .caseChecklistItem:hover { border-color: #93c5fd; transform: translateY(-1px); }
  .caseChecklistItem input { position: absolute; opacity: 0; pointer-events: none; }
  .caseChecklistItem.checked { border-color: #0f172a; background: #0f172a; color: white; }
  .caseCheckIcon { width: 26px; height: 26px; border-radius: 999px; border: 2px solid #cbd5e1; display: inline-flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 900; }
  .caseChecklistItem.checked .caseCheckIcon { border-color: white; background: white; color: #0f172a; }
  .studioEditorList { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; }
  .studioEditorItem { display: grid; grid-template-columns: 1fr 1fr auto; gap: 10px; align-items: center; }
  .laboratoryEditorItem { display: grid; grid-template-columns: 1fr auto; gap: 10px; align-items: center; }
  .databaseActions { display: grid; grid-template-columns: auto 1fr; gap: 10px; align-items: center; margin-bottom: 12px; }
  .databaseButtonGrid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin-bottom: 12px; }
  .databaseButtonGrid.twoCols { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .fileButton { display: inline-flex; align-items: center; justify-content: center; border-radius: 16px; background: #0f172a; color: white; padding: 11px 16px; font-weight: 700; cursor: pointer; text-align: center; }
  .fileButton input { display: none; }
  .icsImportList { display: flex; flex-direction: column; gap: 12px; margin-top: 12px; }
  .icsImportItem { display: grid; grid-template-columns: 1.2fr 1.3fr auto; gap: 12px; align-items: start; border: 1px solid #e2e8f0; background: white; border-radius: 18px; padding: 14px; }
  .icsImportItem p { margin: 6px 0; }
  .icsAssignBox { display: flex; flex-direction: column; gap: 8px; }
  .icsMatches { display: flex; flex-direction: column; gap: 6px; }
  .icsMatchButton { border: 1px solid #cbd5e1; background: #f8fafc; border-radius: 12px; padding: 8px 10px; text-align: left; cursor: pointer; }
  .icsMatchButton:hover { background: #e2e8f0; }
  .icsActions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
  .row { display: flex; gap: 10px; align-items: center; }
  .agendaTwoColumn { display: grid; grid-template-columns: minmax(320px, 0.9fr) minmax(420px, 1.1fr); gap: 18px; align-items: start; }
  .agendaBuilder { display: flex; flex-direction: column; gap: 12px; margin-bottom: 0; }
  .agendaDayPanel { border: 1px solid #bfe0e7; background: #f0f9fa; border-radius: 18px; padding: 16px; }
  .agendaDayPanel h3 { margin-bottom: 12px; }
  .agendaRow { display: flex; flex-direction: column; gap: 6px; }
  .agendaRow span { font-size: 13px; font-weight: 800; color: #475569; }
  .agendaImportBox { border: 1px solid #dbeafe; background: #f8fafc; border-radius: 18px; padding: 14px; }
  .agendaImportBox .icsImportItem { grid-template-columns: 1fr; }
  .agendaImportBox .icsActions { justify-content: flex-start; }
  .compactEmpty { padding: 12px; font-size: 13px; }
  .materialDrawerLayer { position: fixed; z-index: 100; inset: 0; display: flex; justify-content: flex-end; }
  .materialDrawerBackdrop { position: absolute; inset: 0; width: 100%; border: 0; background: rgba(15, 23, 42, 0.38); cursor: pointer; }
  .materialDrawer { position: relative; width: min(620px, 100%); height: 100%; overflow-y: auto; background: #f8fafc; border-left: 1px solid #cbd5e1; padding: 20px; box-shadow: -18px 0 48px rgba(15, 23, 42, 0.2); }
  .materialDrawerHeader { position: sticky; z-index: 2; top: -20px; display: flex; align-items: center; justify-content: space-between; gap: 14px; margin: -20px -20px 16px; padding: 18px 20px; border-bottom: 1px solid #dbe3e8; background: rgba(255, 255, 255, 0.96); }
  .materialDrawerHeader h2 { margin: 0 0 3px; }
  .materialDrawerClose { width: 38px; height: 38px; flex: 0 0 38px; border: 1px solid #cbd5e1; border-radius: 50%; background: white; color: #0f172a; font-size: 24px; line-height: 1; cursor: pointer; }
  .materialDraftBox { display: flex; flex-direction: column; align-items: stretch; gap: 12px; border: 1px solid #bfe0e7; border-radius: 8px; background: white; padding: 14px; }
  .materialDraftGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .materialNotesInput { min-height: 72px; }
  .materialFilters { display: grid; grid-template-columns: 1fr auto; align-items: end; gap: 12px; margin: 16px 0 12px; }
  .materialFilters .checkRow { min-height: 46px; }
  .materialOrderList { display: flex; flex-direction: column; gap: 9px; }
  .materialOrderItem { display: grid; grid-template-columns: minmax(0, 1fr) 150px; gap: 12px; align-items: center; border: 1px solid #dbe3e8; border-radius: 8px; background: white; padding: 12px; }
  .materialOrderItem.received { opacity: 0.65; background: #f1f5f9; }
  .materialOrderMain { min-width: 0; display: flex; flex-direction: column; gap: 3px; }
  .materialOrderMain p { margin: 5px 0 0; white-space: pre-wrap; }
  .materialOrderTitle { display: flex; align-items: center; gap: 7px; flex-wrap: wrap; }
  .materialOrderTitle strong { font-size: 17px; overflow-wrap: anywhere; }
  .urgentMaterial { border-radius: 999px; background: #fee2e2; color: #991b1b; padding: 4px 7px; font-size: 11px; font-weight: 900; text-transform: uppercase; }
  .materialOrderActions { display: flex; flex-direction: column; gap: 7px; }
  .materialOrderActions .input { padding: 8px 9px; font-size: 13px; }
  .agendaDateTime { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .agendaActions { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
  .segmented { display: inline-grid; grid-template-columns: repeat(2, 1fr); gap: 4px; background: #e2e8f0; border-radius: 14px; padding: 4px; }
  .segmented button { border: 0; background: transparent; border-radius: 10px; padding: 8px 12px; font-weight: 900; cursor: pointer; color: #334155; }
  .segmented button.active { background: white; color: #0f172a; box-shadow: 0 5px 12px rgba(15, 23, 42, 0.12); }
  .autosaveNote { color: #64748b; font-size: 13px; font-weight: 700; }
  .agendaNowLine { display: flex; align-items: center; gap: 8px; padding: 5px 0; color: #b91c1c; font-size: 13px; font-weight: 900; }
  .agendaNowLine::after { content: ""; height: 2px; background: #ef4444; flex: 1; }
  .agendaNowLine span { white-space: nowrap; border-radius: 999px; background: #fef2f2; padding: 5px 8px; }
  .agendaList { display: flex; flex-direction: column; gap: 10px; }
  .agendaItem { display: grid; grid-template-columns: 80px 1fr auto auto; gap: 10px; align-items: center; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 12px; }
  .prescriptionAgendaItem { border-color: #f59e0b; background: #fffbeb; }
  .agendaTime { font-size: 20px; font-weight: 900; }
  .agendaMain { display: flex; flex-direction: column; gap: 2px; }
  .agendaMain span { color: #475569; }
  .agendaReasonInput { margin-top: 5px; padding: 7px 9px; border-radius: 9px; }
  .nextAppointmentBox { border-color: #bae6fd; background: #f0f9ff; }
  .nextAppointmentHint { margin: 6px 0 4px; border-left: 3px solid #0f766e; padding: 7px 9px; background: #ecfdf5; border-radius: 0 8px 8px 0; }
  .nextAppointmentHint span { display: block; margin-bottom: 2px; color: #047857; font-size: 12px; font-weight: 900; text-transform: uppercase; }
  .nextAppointmentHint strong { color: #0f172a; font-size: 14px; line-height: 1.35; white-space: pre-wrap; }
  .nextAppointmentHintInline { display: block; border-left: 3px solid #0f766e; padding: 5px 7px; color: #0f172a; background: #ecfdf5; border-radius: 0 7px 7px 0; white-space: pre-wrap; }
  .weekGrid { display: grid; grid-template-columns: repeat(7, minmax(150px, 1fr)); gap: 10px; overflow-x: auto; padding-bottom: 4px; }
  .weekDay { min-width: 150px; border: 1px solid #e2e8f0; background: white; border-radius: 16px; overflow: hidden; display: flex; flex-direction: column; }
  .weekDayHeader { border: 0; border-bottom: 1px solid #e2e8f0; background: #f8fafc; padding: 10px; text-align: left; cursor: pointer; display: flex; flex-direction: column; gap: 3px; font: inherit; }
  .weekDayHeader.active { background: #0f172a; color: white; }
  .weekDayHeader span { font-size: 12px; color: inherit; opacity: 0.78; }
  .weekDayItems { display: flex; flex-direction: column; gap: 8px; padding: 10px; min-height: 220px; }
  .weekAppointment { border: 1px solid #e2e8f0; border-radius: 12px; background: #f8fafc; padding: 8px; text-align: left; display: flex; flex-direction: column; gap: 6px; font: inherit; }
  .weekAppointment:hover { border-color: #94a3b8; background: white; }
  .weekAppointment strong { font-size: 14px; }
  .weekAppointment span { font-weight: 800; }
  .weekAppointment small { color: #64748b; }
  .weekAppointment.prescription { border-color: #f59e0b; background: #fffbeb; }
  .weekReasonInput { width: 100%; border: 1px solid #cbd5e1; border-radius: 9px; padding: 7px 8px; font: inherit; font-size: 12px; background: white; }
  .agendaRecallPanel { margin-top: 18px; border: 1px solid #c7e2df; border-radius: 18px; background: #f8fafc; overflow: hidden; }
  .agendaRecallPanel > summary { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 14px 16px; cursor: pointer; font-weight: 900; color: #0f172a; list-style: none; }
  .agendaRecallPanel > summary::-webkit-details-marker { display: none; }
  .agendaRecallPanel > summary span { color: #0f766e; }
  .agendaRecallPanel > summary strong { border-radius: 999px; background: #fff7dd; color: #854d0e; padding: 6px 10px; font-size: 12px; }
  .agendaRecallPanel[open] > summary { border-bottom: 1px solid #dbeafe; background: white; }
  .agendaRecallPanel .recallFilters, .agendaRecallPanel .recallList { margin: 14px; }
  .recallFilters { display: grid; grid-template-columns: minmax(170px, 1fr) minmax(170px, 1fr) minmax(170px, 1fr) auto; gap: 12px; align-items: end; margin-bottom: 16px; }
  .recallExcludedToggle { align-self: center; padding: 12px 0; }
  .recallList { display: flex; flex-direction: column; gap: 10px; }
  .recallItem { display: grid; grid-template-columns: 130px 1fr auto auto auto; gap: 12px; align-items: center; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 12px; }
  .recallItem.excluded { opacity: 0.62; background: #f1f5f9; }
  .recallAge { border-radius: 14px; background: white; border: 1px solid #e2e8f0; padding: 10px; display: flex; flex-direction: column; gap: 2px; }
  .recallAge strong { font-size: 20px; }
  .recallAge span, .recallMain span, .recallMain small { color: #64748b; }
  .recallMain { display: flex; flex-direction: column; gap: 3px; }
  .recallMain strong { font-size: 18px; }
  .recallExcludeCheck { white-space: nowrap; }
  .emptyState { border: 1px dashed #cbd5e1; color: #64748b; background: #f8fafc; border-radius: 18px; padding: 18px; text-align: center; }
  .collapsibleBox { border: 1px solid #e2e8f0; border-radius: 18px; background: #f8fafc; margin: 14px 0; overflow: hidden; }
  .collapsibleHeader { width: 100%; border: 0; background: white; padding: 14px 16px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; font: inherit; }
  .collapsibleHeader span { color: #64748b; font-size: 13px; font-weight: 800; }
  .elasticBox { border: 0; border-top: 1px solid #e2e8f0; border-radius: 0; padding: 14px; background: #f8fafc; margin: 0; }
  .elasticControls { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 12px; }
  .elasticSvg { width: 100%; height: 260px; border-radius: 16px; background: white; border: 1px solid #e2e8f0; }
  .elasticList { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
  .elasticChip { border: 0; border-radius: 999px; padding: 7px 11px; background: #0f172a; color: white; cursor: pointer; }
  .muted { color: #64748b; font-size: 14px; }
  small { color: #64748b; }
  .photoUploader { border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 16px; display: flex; flex-direction: column; gap: 14px; margin-bottom: 18px; }
  .photoHelpBox { border: 1px solid #bae6fd; background: #f0f9ff; color: #0f172a; border-radius: 16px; padding: 12px 14px; margin-bottom: 14px; font-size: 14px; line-height: 1.45; }
  .photoSearchBox { display: flex; align-items: end; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
  .photoDateSearchPanel { display: grid; grid-template-columns: minmax(240px, 1fr) minmax(210px, 280px) auto; gap: 12px; align-items: end; border: 1px solid #bae6fd; background: #f0f9ff; border-radius: 18px; padding: 14px; margin-bottom: 18px; }
  .photoDateSearchPanel > div { display: flex; flex-direction: column; gap: 3px; }
  .photoDateSearchPanel span { color: #0369a1; font-size: 12px; font-weight: 900; text-transform: uppercase; }
  .photoDateSearchPanel strong { color: #0f172a; font-size: 17px; }
  .photoDateSearchPanel small { color: #475569; }
  .photoSearchResults { margin-bottom: 18px; }
  .photoEditGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px; }
  .rxArrivedCheck { display: flex; align-items: center; gap: 8px; margin-top: 4px; }
  .rxArrivedCheck input { width: 18px; height: 18px; accent-color: #0f172a; }
  .folderDropZone { border: 1px dashed #94a3b8; background: white; border-radius: 18px; padding: 14px; }
  .folderDropZone:hover { border-color: #0f172a; }
  .treatmentSummaryBox { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 14px 0 22px; }
  .photoGrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; }
  .photoThumb { position: relative; display: block; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; background: white; aspect-ratio: 4 / 3; }
  .photoThumb img { width: 100%; height: 100%; object-fit: contain; display: block; background: #f8fafc; }
  .photoThumb button { position: absolute; top: 6px; right: 6px; width: 26px; height: 26px; border: 0; border-radius: 999px; background: rgba(15, 23, 42, 0.85); color: white; cursor: pointer; font-weight: 900; }
  .photoSessionList { display: flex; flex-direction: column; gap: 14px; }
  .photoSession { border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; padding: 14px; }
  .diaryAutosaveRow { display: flex; align-items: center; justify-content: space-between; gap: 12px; border: 1px solid #bbf7d0; background: #f0fdf4; border-radius: 14px; padding: 10px 12px; }
  .diaryAutosaveRow span { color: #166534; font-size: 13px; font-weight: 800; }
  .folderPath { display: block; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; word-break: break-all; background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 8px; margin: 8px 0; color: #0f172a; text-decoration: none; }
  .photoPathActions { display: flex; flex-wrap: wrap; gap: 8px; margin: 8px 0; }
  .localPathNote { display: block; margin-top: 4px; }
  .photoSaveRow { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
  .linkedPhotoInfo { display: block; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 8px; margin-top: 8px; word-break: break-word; }
  .alignerDeliveryBox { display: flex; flex-direction: column; gap: 14px; margin: 14px 0; padding: 14px; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 18px; }
  .coverageBox { background: #0f172a; color: white; border-radius: 16px; padding: 12px 14px; font-weight: 800; }
  .alignerScheduleDetails { border: 1px solid #e2e8f0; border-radius: 16px; background: white; overflow: hidden; }
  .alignerScheduleDetails summary { cursor: pointer; padding: 11px 12px; font-weight: 900; color: #0f172a; }
  .alignerScheduleDetails[open] summary { border-bottom: 1px solid #e2e8f0; }
  .alignerScheduleTable { border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; background: white; }
  .alignerScheduleDetails .alignerScheduleTable { border: 0; border-radius: 0; }
  .alignerScheduleRow { display: grid; grid-template-columns: 80px 1fr 1fr; gap: 10px; padding: 9px 12px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
  .alignerScheduleRow:last-child { border-bottom: 0; }
  .savedSchedule { margin-top: 10px; }
  @media (max-width: 1100px) {
    .layout, .diaryGrid, .agendaTwoColumn, .agendaBuilder, .agendaItem, .studioEditorItem, .laboratoryEditorItem, .databaseActions, .databaseButtonGrid, .databaseButtonGrid.twoCols, .icsImportItem, .quoteGrid, .recallFilters, .recallItem, .patientPickerBar, .photoDateSearchPanel { grid-template-columns: 1fr; }
    .header { flex-direction: column; align-items: flex-start; }
    .topDatabaseActions { justify-content: flex-start; }
  }
  @media (max-width: 800px) {
    .app { padding: 14px; }
    .grid2, .grid3, .grid4, .agendaDateTime, .treatmentSummaryBox, .photoEditGrid, .caseChecklistGrid, .quoteEstimateGrid, .materialDraftGrid, .materialFilters, .materialOrderItem { grid-template-columns: 1fr; }
    .materialDrawer { padding: 14px; }
    .materialDrawerHeader { top: -14px; margin: -14px -14px 14px; padding: 14px; }
    .topDatabaseActions { width: 100%; }
    .topDatabaseActions .btn, .topDatabaseActions .fileButton, .topDatabaseActions .topActionButton { flex: 1 1 100%; }
    .saveDestinationBox { align-items: stretch; flex-direction: column; }
    .tabs { grid-template-columns: repeat(2, 1fr); }
    .globalPatientMatches { position: static; margin-top: 10px; }
  }
`;
