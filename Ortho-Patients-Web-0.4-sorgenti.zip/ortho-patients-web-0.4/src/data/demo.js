import { initialPatients, defaultStudios, defaultLaboratories } from './defaults.js';
import { localDateISO } from '../lib/agendaUtils.js';

export function createDemoData(now = new Date()) {
  const studios = [
    { ...defaultStudios[0], nome: 'Studio Centro · demo', indirizzo: '' },
    { id: 'studio-2', nome: 'Studio Levante · demo', indirizzo: '', telefono: '', email: '' }
  ];
  const template = initialPatients[0];
  const patients = [
    { ...structuredClone(template), id: 'demo-1', nome: 'Mario', cognome: 'Rossi', pseudonimo: 'DEMO-01', trattamento: 'fissa', prossimoAppuntamento: 'Cambio arco e controllo elastici' },
    { ...structuredClone(template), id: 'demo-2', nome: 'Giulia', cognome: 'Bianchi', pseudonimo: 'DEMO-02', studioId: 'studio-2', trattamento: 'allineatori', prossimoAppuntamento: 'Consegna allineatori e controllo adattamento' },
    { ...structuredClone(template), id: 'demo-3', nome: 'Luca', cognome: 'Verdi', pseudonimo: 'DEMO-03', trattamento: 'contenzione', prossimoAppuntamento: 'Controllo della contenzione' }
  ];
  const minutes = now.getHours() * 60 + now.getMinutes();
  const time = (offset) => {
    const value = Math.max(0, Math.min(1439, minutes + offset));
    return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
  };
  return {
    studios, patients, laboratories: defaultLaboratories, selectedId: 'demo-1', materialOrders: [],
    agendaItems: patients.map((patient, index) => ({
      id: `demo-appointment-${index}`, patientId: patient.id, studioId: patient.studioId,
      data: localDateISO(now), ora: time([-60, 30, 90][index]), motivo: patient.prossimoAppuntamento
    }))
  };
}
