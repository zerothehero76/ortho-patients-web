export const appVersion = "0.4";
export const appReleaseDate = "15.10.2026";

export const defaultWireSequence = [
  "---",
  "0.014 NiTi",
  "0.016 NiTi",
  "0.018 NiTi",
  "0.016x0.022 NiTi",
  "0.019x0.025 NiTi",
  "0.019x0.025 SS",
  "Finitura"
];

export const defaultLingualWireSequence = [
  "---",
  "0.012 NiTi",
  "0.014 NiTi",
  "0.016 NiTi",
  "0.016x0.022 NiTi",
  "0.018x0.025 NiTi",
  "0.018x0.025 SS",
  "Finitura"
];

export const defaultStudios = [
  {
    id: "studio-1",
    nome: "Centro di Ortodonzia",
    indirizzo: "Genova",
    telefono: "",
    email: ""
  }
];

export const defaultLaboratories = [
  {
    id: "lab-1",
    nome: "Laboratorio non specificato"
  }
];

export const defaultDiagnosis = {
  classeDentale: "I",
  classeScheletrica: "I",
  divergenza: "normodivergente",
  faseCrescita: "",
  cc: "",
  agenesieSovrannumerari: "",
  discrepanzaTrasversale: "no",
  notaLibera: "",
  pianoTerapeutico: {
    durataPrevista: "",
    obiettivi: ""
  }
};

export const defaultCaseChecklist = {
  foto: false,
  opt: false,
  tele: false,
  scansione: false,
  ceph: false
};

export const caseChecklistLabels = {
  foto: "Foto",
  opt: "OPT",
  tele: "Tele",
  scansione: "Scansione",
  ceph: "Ceph"
};

export const initialPatients = [
  {
    id: "p-1",
    nome: "Mario",
    cognome: "Rossi",
    dataNascita: "2012-04-12",
    pseudonimo: "MR-2012",
    email: "",
    telefono: "",
    codiceFiscale: "",
    indirizzo: "",
    studioId: "studio-1",
    trattamento: "studio_caso",
    dataInizioTrattamento: "",
    preventivo: "",
    dataFineTrattamentoAttivo: "",
    dataUltimoControlloContenzione: "",
    noteTrattamento: "",
    prossimoAppuntamento: "",
    studioCasoChecklist: defaultCaseChecklist,
    esclusoRecall: false,
    diagnosi: defaultDiagnosis,
    igiene: 6,
    compliance: 7,
    arcoSupIndex: 0,
    arcoInfIndex: 0,
    alignerCorrente: 1,
    alignerTotali: 24,
    prescrizioni: [],
    photoSessions: [],
    diario: []
  }
];
